#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <fstream>
#include <shellapi.h>
#include <mmsystem.h>
#include <thread>
#include <atomic>
#include <chrono>
#include <deque>
#include <mutex>
#include <gdiplus.h>
#include <dwmapi.h>
#include <commctrl.h>
#include <ole2.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <list>
#include <psapi.h>

// Per il linking statico
#define STATIC_LINK
#ifndef STATIC_LINK
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "dwmapi.lib")
#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "psapi.lib")
#endif

// Global variables
std::atomic<bool> isRunning(true);
std::atomic<bool> panicMode(false);
std::atomic<int> effectIntensity(0);  // 0-10 scale of effect intensity
HHOOK keyboardHook = NULL;
std::vector<HWND> createdWindows;
std::vector<HANDLE> threadHandles;
std::mutex windowsMutex;
std::mutex screenCaptureMutex;
std::mutex iconsMutex;
std::deque<HBITMAP> screenHistory;
std::mt19937 rng(GetTickCount());
HBITMAP screenBitmap = NULL;
int screenWidth = GetSystemMetrics(SM_CXSCREEN);
int screenHeight = GetSystemMetrics(SM_CYSCREEN);
bool tunnelStarted = false;
DWORD programStartTime = 0;
HWND controlWindow = NULL;

// Lista degli icone permanenti da disegnare
struct PermanentIcon {
    int x;
    int y;
    int type; // 0 = error, 1 = warning, 2 = info, 3 = text
    std::string text;
    COLORREF color;
};
std::list<PermanentIcon> permanentIcons;

// Maximum number of windows to create for tunnel effect
const int MAX_TUNNEL_WINDOWS = 50; // Aumentato per maggior effetto

// Durata totale della simulazione in millisecondi (3 minuti)
const DWORD TOTAL_DURATION = 180000;

// Websites to open
const std::vector<std::string> websites = {
    "https://www.google.com/search?q=how+2+remove+a+virus",
    "https://www.google.com/search?q=mcaffee+vs+norton",
    "https://www.google.com/search?q=how+to+send+a+virus+to+my+friend",
    "https://www.google.com/search?q=minecraft+hax+download+no+virus",
    "https://www.google.com/search?q=how+to+get+money",
    "https://www.google.com/search?q=bonzi+buddy+download+free",
    "https://www.google.com/search?q=how+2+get+weed+out+of+ur+system",
    "https://www.google.com/search?q=how+to+code+a+virus+in+visual+basic",
    "https://www.google.com/search?q=what+happens+if+you+delete+system32",
    "https://www.google.com/search?q=g3t+r3kt",
    "https://www.google.com/search?q=batch+virus+download",
    "https://www.google.com/search?q=virus.exe",
    "https://www.google.com/search?q=internet+explorer+is+the+best+browseraaaaaaaaaaaaaaaaaaaaaaa",
    "https://www.google.com/search?q=facebook+hacking+tool+free+download+no+virus+working+2016",
    "https://www.google.com/search?q=virus+builder+legit+free+download",
    "https://www.google.com/search?q=how+to+create+your+own+ransomware",
    "https://www.google.com/search?q=how+to+remove+memz+trojan+virus",
    "https://www.google.com/search?q=my+computer+is+doing+weird+things+wtf+is+happenin+plz+halp",
    "https://www.google.com/search?q=dank+memz",
    "https://www.google.com/search?q=how+to+download+memz",
    "https://www.google.com/search?q=half+life+3+release+date",
    "https://www.google.com/search?q=is+illuminati+real",
    "https://www.google.com/search?q=montage+parody+making+program+2016",
    "https://www.google.com/search?q=the+memz+are+real",
    "https://www.google.com/search?q=stanky+danky+maymays",
    "https://www.google.com/search?q=john+cena+midi+legit+not+converted",
    "https://www.google.com/search?q=vinesauce+meme+collection",
    "https://www.google.com/search?q=skrillex+scay+onster+an+nice+sprites+midi",
    "https://answers.microsoft.com/en-us/protect/forum/protect_other-protect_scanning/memz-malwarevirus-trojan-completely-destroying/268bc1c2-39f4-42f8-90c2-597a673b6b45",
    "https://motherboard.vice.com/read/watch-this-malware-turn-a-computer-into-a-digital-hellscape",
    "https://www.disney.com"
};

// Windows applications to open
const std::vector<std::string> applications = {
    "calc.exe",
    "notepad.exe",
    "cmd.exe",
    "write.exe",
    "regedit.exe",
    "explorer.exe",
    "taskmgr.exe",
    "msconfig.exe",
    "mspaint.exe",
    "devmgmt.msc",
    "control.exe",
    "mmc.exe"
};

// Error messages when process is terminated
const std::vector<std::string> errorMessages = {
    "YOU KILLED MY TROJAN! Now you are going to die.",
    "REST IN PISS, FOREVER MISS",
    "I WARNED YOU...",
    "HAHA N00B L2P G3T R3KT",
    "You failed at your 1337 h4x0r skillz",
    "YOU TRIED SO HARD AND GOT SO FAR, BUT IN THE END, YOUR PC WAS STILL F***ED!",
    "HACKER! ENJOY BAN!",
    "GET BETTER HAX NEXT TIME xD",
    "HAVE FUN TRYING TO RESTORE YOUR DATA :D",
    "|\\/|3|\\/|2",
    "BSOD INCOMING",
    "VIRUS PRANK (GONE WRONG)",
    "ENJOY THE NYAN CAT",
    "Get dank antivirus m9!",
    "You are an idiot! HA HA HA HA HA HA HA",
    "MakeMalwareGreatAgain",
    "SOMEBODY ONCE TOLD ME THE MEMZ ARE GONNA ROLL ME",
    "Why did you even tried to kill MEMZ? Your PC is f***ed anyway.",
    "SecureBoot sucks.",
    "gr8 m8 i r8 8/8",
    "Have you tried turning it off and on again?",
    "<Insert Joel quote here>",
    "Greetings to all GAiA members!",
    "Well, hello there. I don't believe we've been properly introduced. I'm Bonzi!",
    "This is everything I want in my computer – danooct1 2016",
    "Uh, Club Penguin. Time to get banned! – danooct1 2016"
};

// Forward declarations
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK TunnelWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void CleanupResources();
HBITMAP CreateScreenCapture();
void DrawChaos(HDC hdc, int width, int height);
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);

// IMPORTANTE: Aggiungi le dichiarazioni anticipate delle funzioni thread
DWORD WINAPI ShowErrorMessagesThread(LPVOID lpParam);
DWORD WINAPI OpenWebsitesThread(LPVOID lpParam);
DWORD WINAPI OpenApplicationsThread(LPVOID lpParam);
DWORD WINAPI RandomMouseThread(LPVOID lpParam);
DWORD WINAPI StillUsingThread(LPVOID lpParam);
DWORD WINAPI DrawErrorIconsThread(LPVOID lpParam);
DWORD WINAPI ScreenCaptureThread(LPVOID lpParam);
DWORD WINAPI TunnelWindowsThread(LPVOID lpParam);
DWORD WINAPI InvertColorsThread(LPVOID lpParam);
DWORD WINAPI DrawGDIChaosThread(LPVOID lpParam);
DWORD WINAPI SimulateBSODThread(LPVOID lpParam);
DWORD WINAPI WatchdogThread(LPVOID lpParam);
DWORD WINAPI ProcessMonitorThread(LPVOID lpParam);
DWORD WINAPI DrawPermanentIconsThread(LPVOID lpParam);

// Message box intercept (to prevent normal closing)
HHOOK msgBoxHook = NULL;
LRESULT CALLBACK CBTProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HCBT_ACTIVATE) {
        HWND hwnd = (HWND)wParam;
        if (GetDlgItem(hwnd, IDCANCEL) != NULL) {
            // Hide cancel button
            ShowWindow(GetDlgItem(hwnd, IDCANCEL), SW_HIDE);
        }
    }
    return CallNextHookEx(msgBoxHook, nCode, wParam, lParam);
}

// Calcola l'intensità dell'effetto in base al tempo trascorso
void UpdateEffectIntensity() {
    // Calcola quanto tempo è passato dall'inizio del programma
    DWORD elapsedTime = GetTickCount() - programStartTime;

    // Calcola percentuale di progresso (0.0 - 1.0)
    float progress = (float)elapsedTime / TOTAL_DURATION;

    // Limita il progresso a 1.0
    if (progress > 1.0f) progress = 1.0f;

    // Scala il progresso non linearmente per renderlo più graduale all'inizio
    // e più intenso alla fine (funzione esponenziale)
    float scaledProgress = powf(progress, 1.5f) * 10;

    // Aggiorna l'intensità (0-10)
    effectIntensity = (int)scaledProgress;
}

// Keyboard hook procedure for panic button (ESC key)
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode >= 0) {
        KBDLLHOOKSTRUCT* kbStruct = (KBDLLHOOKSTRUCT*)lParam;

        // Check if ESC key was pressed (VK_ESCAPE = 27)
        if (wParam == WM_KEYDOWN && kbStruct->vkCode == VK_ESCAPE) {
            panicMode = true;
            isRunning = false;

            // Show message that we're exiting
            MessageBoxA(NULL, "🚨 PANIC BUTTON PRESSED 🚨\n\nShutting down all effects...\nPlease wait while cleanup occurs.",
                      "MEMZ Simulator - PANIC MODE", MB_OK | MB_ICONINFORMATION);

            // Cleanup immediately
            CleanupResources();
            ExitProcess(0);
        }
    }

    return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
}

// Register window classes
void RegisterWindowClasses(HINSTANCE hInstance) {
    // Register main window class
    WNDCLASSA wc = {0};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "MEMZSimulatorClass";
    RegisterClassA(&wc);

    // Register tunnel window class
    WNDCLASSA tunnelWc = {0};
    tunnelWc.lpfnWndProc = TunnelWindowProc;
    tunnelWc.hInstance = hInstance;
    tunnelWc.lpszClassName = "MEMZTunnelClass";
    RegisterClassA(&tunnelWc);
}

// Function to create warning message
bool ShowWarningMessage(const std::string& message) {
    int result = MessageBoxA(NULL, message.c_str(), "⚠️ MEMZ Simulator - WARNING ⚠️", MB_YESNO | MB_ICONWARNING);
    return (result == IDYES);
}

// Function to create text file
void CreateTextFile() {
    std::ofstream file("MEMZ_WARNING.txt");
    if (file.is_open()) {
        file << "⚠️ THIS IS A SIMULATION ⚠️\n\n";
        file << "If this were the real MEMZ trojan, your computer would no longer be able to boot.\n";
        file << "DO NOT RESTART YOUR SYSTEM (if this were real).\n\n";
        file << "This is a safe simulation for educational purposes only.\n";
        file << "Created for Matteo.\n\n";
        file << "PANIC BUTTON: Press ESC key at any time to immediately stop all effects.\n\n";
        file << "NOTE: The effects will get progressively more chaotic and intense\n";
        file << "      over approximately 3 minutes to accurately simulate the real\n";
        file << "      MEMZ trojan, but your system is completely safe.\n";
        file << "      No data will be harmed.";
        file.close();
        ShellExecuteA(NULL, "open", "MEMZ_WARNING.txt", NULL, NULL, SW_SHOW);
    }
}

// Capture screen to bitmap
HBITMAP CreateScreenCapture() {
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    HBITMAP hBitmap = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);
    HGDIOBJ hOld = SelectObject(hdcMem, hBitmap);

    // Copy screen to memory DC
    BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);

    // Clean up
    SelectObject(hdcMem, hOld);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    return hBitmap;
}

// Draw chaotic visuals on the screen
void DrawChaos(HDC hdc, int width, int height) {
    int intensity = effectIntensity.load();
    if (intensity <= 0) return;

    // Number of elements to draw scales with intensity
    int numElements = intensity * 20;

    // Create brushes and pens for drawing
    HBRUSH redBrush = CreateSolidBrush(RGB(255, 0, 0));
    HBRUSH greenBrush = CreateSolidBrush(RGB(0, 255, 0));
    HBRUSH blueBrush = CreateSolidBrush(RGB(0, 0, 255));
    HBRUSH yellowBrush = CreateSolidBrush(RGB(255, 255, 0));
    HBRUSH purpleBrush = CreateSolidBrush(RGB(255, 0, 255));

    HPEN redPen = CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
    HPEN greenPen = CreatePen(PS_SOLID, 2, RGB(0, 255, 0));
    HPEN bluePen = CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
    HPEN yellowPen = CreatePen(PS_SOLID, 2, RGB(255, 255, 0));
    HPEN purplePen = CreatePen(PS_SOLID, 2, RGB(255, 0, 255));

    HBRUSH brushes[] = {redBrush, greenBrush, blueBrush, yellowBrush, purpleBrush};
    HPEN pens[] = {redPen, greenPen, bluePen, yellowPen, purplePen};
    int numBrushes = sizeof(brushes) / sizeof(brushes[0]);

    // Create distribution for random positions and sizes
    std::uniform_int_distribution<int> xDist(0, width);
    std::uniform_int_distribution<int> yDist(0, height);
    std::uniform_int_distribution<int> sizeDist(10, 100);
    std::uniform_int_distribution<int> elementDist(0, 5); // Different types of elements
    std::uniform_int_distribution<int> colorDist(0, numBrushes - 1);

    // Draw random elements
    for (int i = 0; i < numElements; i++) {
        int x = xDist(rng);
        int y = yDist(rng);
        int size = sizeDist(rng);
        int elementType = elementDist(rng);
        int colorIndex = colorDist(rng);

        // Select brush and pen
        HBRUSH hBrush = brushes[colorIndex];
        HPEN hPen = pens[colorIndex];

        HBRUSH oldBrush = (HBRUSH)SelectObject(hdc, hBrush);
        HPEN oldPen = (HPEN)SelectObject(hdc, hPen);

        // Draw element based on type
        switch (elementType) {
            case 0: // Rectangle
                Rectangle(hdc, x, y, x + size, y + size);
                break;

            case 1: // Ellipse
                Ellipse(hdc, x, y, x + size, y + size);
                break;

            case 2: // Line
                MoveToEx(hdc, x, y, NULL);
                LineTo(hdc, x + size, y + size);
                break;

            case 3: // Triangle
                {
                    POINT points[3] = {
                        {x, y + size},
                        {x + size / 2, y},
                        {x + size, y + size}
                    };
                    Polygon(hdc, points, 3);
                }
                break;

            case 4: // Draw system icons
                {
                    int iconType = colorIndex % 3;
                    HICON hIcon = NULL;

                    switch (iconType) {
                        case 0:
                            hIcon = LoadIcon(NULL, IDI_ERROR);
                            break;
                        case 1:
                            hIcon = LoadIcon(NULL, IDI_WARNING);
                            break;
                        case 2:
                            hIcon = LoadIcon(NULL, IDI_INFORMATION);
                            break;
                    }

                    if (hIcon) {
                        DrawIcon(hdc, x, y, hIcon);
                        DestroyIcon(hIcon);
                    }
                }
                break;

            case 5: // Draw text
                {
                    // Select random text to draw
                    const char* texts[] = {
                        "MEMZ", "HACKED", "VIRUS", "RIP PC", "L0L", "PWN3D",
                        "G3T R3KT", "TROJAN", "MALWARE", "DELETED", "ERR0R"
                    };
                    int textIndex = colorIndex % (sizeof(texts) / sizeof(texts[0]));

                    SetTextColor(hdc, RGB(255, 0, 0));
                    SetBkMode(hdc, TRANSPARENT);
                    TextOutA(hdc, x, y, texts[textIndex], strlen(texts[textIndex]));
                }
                break;
        }

        // Restore original objects
        SelectObject(hdc, oldPen);
        SelectObject(hdc, oldBrush);
    }

    // Clean up
    for (int i = 0; i < numBrushes; i++) {
        DeleteObject(brushes[i]);
        DeleteObject(pens[i]);
    }
}

// Draw persistent icons that non si cancellano
void DrawPermanentIcons(HDC hdc) {
    std::lock_guard<std::mutex> lock(iconsMutex);

    HICON errorIcon = LoadIcon(NULL, IDI_ERROR);
    HICON warningIcon = LoadIcon(NULL, IDI_WARNING);
    HICON infoIcon = LoadIcon(NULL, IDI_INFORMATION);

    for (const auto& icon : permanentIcons) {
        switch (icon.type) {
            case 0: // Error
                DrawIcon(hdc, icon.x, icon.y, errorIcon);
                break;
            case 1: // Warning
                DrawIcon(hdc, icon.x, icon.y, warningIcon);
                break;
            case 2: // Info
                DrawIcon(hdc, icon.x, icon.y, infoIcon);
                break;
            case 3: // Text
                SetTextColor(hdc, icon.color);
                SetBkMode(hdc, TRANSPARENT);
                TextOutA(hdc, icon.x, icon.y, icon.text.c_str(), icon.text.length());
                break;
        }
    }

    DestroyIcon(errorIcon);
    DestroyIcon(warningIcon);
    DestroyIcon(infoIcon);
}

// Thread per disegnare le icone permanenti
DWORD WINAPI DrawPermanentIconsThread(LPVOID lpParam) {
    while (isRunning) {
        // Se l'intensità è abbastanza alta, disegna le icone persistenti
        if (effectIntensity.load() >= 2) {
            HDC hdcScreen = GetDC(NULL);
            DrawPermanentIcons(hdcScreen);
            ReleaseDC(NULL, hdcScreen);
        }

        // Aggiorna con la frequenza che dipende dall'intensità
        int intensity = effectIntensity.load();
        Sleep(std::max(50, 200 - (intensity * 15)));
    }

    return 0;
}

// Create a tunnel window
HWND CreateTunnelWindow(HINSTANCE hInstance, int index) {
    // Calculate position and size
    float scale = 0.95f - (0.015f * index); // Each window gets smaller
    int width = (int)(screenWidth * scale);
    int height = (int)(screenHeight * scale);
    int x = (screenWidth - width) / 2;
    int y = (screenHeight - height) / 2;

    // Add some variation to position for chaos effect
    if (index > 0) {
        std::uniform_int_distribution<int> offsetDist(-10, 10);
        x += offsetDist(rng);
        y += offsetDist(rng);
    }

    // Create window with translucent extended style
    HWND hwnd = CreateWindowExA(
        WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TRANSPARENT,
        "MEMZTunnelClass",
        (std::string("MEMZ Tunnel ") + std::to_string(index)).c_str(),
        WS_POPUP | WS_VISIBLE,
        x, y, width, height,
        NULL, NULL, hInstance, NULL
    );

    // Set window transparency
    SetLayeredWindowAttributes(hwnd, 0, 230, LWA_ALPHA); // Più opaco per un effetto migliore

    // Store the index in the window user data
    SetWindowLongPtr(hwnd, GWLP_USERDATA, index);

    return hwnd;
}

// Window procedure for tunnel windows
LRESULT CALLBACK TunnelWindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CREATE:
            return 0;

        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hwnd, &ps);

                // Get window size
                RECT rc;
                GetClientRect(hwnd, &rc);
                int width = rc.right - rc.left;
                int height = rc.bottom - rc.top;

                // Get window index
                int index = (int)GetWindowLongPtr(hwnd, GWLP_USERDATA);

                // Create memory DC for double buffering
                HDC hdcMem = CreateCompatibleDC(hdc);
                HBITMAP hBitmap = CreateCompatibleBitmap(hdc, width, height);
                HGDIOBJ hOldBitmap = SelectObject(hdcMem, hBitmap);

                // Fill background
                HBRUSH hBrush = NULL;

                // Choose different colors based on index for visual chaos
                switch (index % 5) {
                    case 0:
                        hBrush = CreateSolidBrush(RGB(0, 0, 0)); // Black
                        break;
                    case 1:
                        hBrush = CreateSolidBrush(RGB(0, 0, 128)); // Dark blue
                        break;
                    case 2:
                        hBrush = CreateSolidBrush(RGB(128, 0, 0)); // Dark red
                        break;
                    case 3:
                        hBrush = CreateSolidBrush(RGB(0, 128, 0)); // Dark green
                        break;
                    case 4:
                        hBrush = CreateSolidBrush(RGB(128, 0, 128)); // Dark purple
                        break;
                }

                FillRect(hdcMem, &rc, hBrush);
                DeleteObject(hBrush);

                // Draw screen capture if available
                {
                    std::lock_guard<std::mutex> lock(screenCaptureMutex);
                    // Corretto il confronto tra tipi diversi
                    if (!screenHistory.empty() && (index < (int)screenHistory.size())) {
                        HBITMAP hCapture = screenHistory[index];
                        if (hCapture) {
                            // Create DC for the captured bitmap
                            HDC hdcCapture = CreateCompatibleDC(hdcMem);
                            HGDIOBJ hOldCapture = SelectObject(hdcCapture, hCapture);

                            // Draw the captured screen with various effects
                            int effect = index % 4;

                            switch (effect) {
                                case 0: // Normal
                                    StretchBlt(hdcMem, 0, 0, width, height,
                                              hdcCapture, 0, 0, screenWidth, screenHeight,
                                              SRCCOPY);
                                    break;

                                case 1: // Inverted
                                    StretchBlt(hdcMem, 0, 0, width, height,
                                              hdcCapture, 0, 0, screenWidth, screenHeight,
                                              NOTSRCCOPY);
                                    break;

                                case 2: // XOR effect
                                    StretchBlt(hdcMem, 0, 0, width, height,
                                              hdcCapture, 0, 0, screenWidth, screenHeight,
                                              SRCINVERT);
                                    break;

                                case 3: // Weird blend
                                    StretchBlt(hdcMem, 0, 0, width, height,
                                              hdcCapture, 0, 0, screenWidth, screenHeight,
                                              SRCAND);
                                    break;
                            }

                            // Clean up
                            SelectObject(hdcCapture, hOldCapture);
                            DeleteDC(hdcCapture);
                        }
                    }
                }

                // Draw additional chaos elements
                DrawChaos(hdcMem, width, height);

                // Copy from memory DC to window DC
                BitBlt(hdc, 0, 0, width, height, hdcMem, 0, 0, SRCCOPY);

                // Clean up
                SelectObject(hdcMem, hOldBitmap);
                DeleteObject(hBitmap);
                DeleteDC(hdcMem);

                EndPaint(hwnd, &ps);
                return 0;
            }

        case WM_DESTROY:
            return 0;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

// Main window procedure
LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
        case WM_CLOSE:
            if (!panicMode) {
                // Show random error messages before closing
                HANDLE errorThread = CreateThread(NULL, 0, ShowErrorMessagesThread, NULL, 0, NULL);
                threadHandles.push_back(errorThread);
                return 0; // Prevent closing
            }
            DestroyWindow(hwnd);
            return 0;

        case WM_DESTROY:
            isRunning = false;
            PostQuitMessage(0);
            return 0;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

// Monitor for process termination attempts
DWORD WINAPI ProcessMonitorThread(LPVOID lpParam) {
    DWORD processId = GetCurrentProcessId();
    HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, processId);

    if (hProcess == NULL) {
        return 0;
    }

    while (isRunning) {
        // Check if someone is trying to terminate us with Task Manager
        // Monitoring per chiusura forzata

        // Enumera tutte le finestre per vedere se Task Manager è aperto
        EnumWindows(EnumWindowsProc, 0);

        // Se c'è un tentativo di terminazione o altre finestre aperte
        if (!isRunning && !panicMode) {
            // Attiva la sequenza BSOD
            HANDLE bsodThread = CreateThread(NULL, 0, SimulateBSODThread, NULL, 0, NULL);
            CloseHandle(bsodThread);
            break;
        }

        Sleep(500);
    }

    CloseHandle(hProcess);
    return 0;
}

// Enumera finestre per rilevare Task Manager e altri tentativi di terminazione
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam) {
    if (!IsWindowVisible(hwnd)) {
        return TRUE;
    }

    char windowTitle[256];
    GetWindowTextA(hwnd, windowTitle, sizeof(windowTitle));

    // Controlla se è Task Manager o Process Explorer
    if (strstr(windowTitle, "Task Manager") ||
        strstr(windowTitle, "Process Explorer") ||
        strstr(windowTitle, "Process Hacker")) {

        // Prova a determinare quale processo è stato selezionato
        DWORD processId = 0;
        GetWindowThreadProcessId(hwnd, &processId);

        // Se sembra che stiano cercando di terminare il nostro processo
        if (processId != 0) {
            // Solo una probabilità che attivi il BSOD
            if (rand() % 5 == 0 && !panicMode) {
                // Simula un tentativo di terminazione
                HANDLE errorThread = CreateThread(NULL, 0, ShowErrorMessagesThread, NULL, 0, NULL);
                WaitForSingleObject(errorThread, 3000);
                CloseHandle(errorThread);

                isRunning = false;

                // Non continua l'enumerazione
                return FALSE;
            }
        }
    }

    return TRUE;  // Continua a enumerare
}

// Function to open websites
DWORD WINAPI OpenWebsitesThread(LPVOID lpParam) {
    // Open multiple sites simultaneously for chaos
    int numSimultaneous = 1; // Start with 1 to be more gradual
    int totalOpened = 0;

    // Corretto il confronto tra tipi diversi
    while (isRunning && totalOpened < (int)websites.size()) {
        // Aspetta che l'intensità raggiunga almeno 1 prima di iniziare
        if (effectIntensity.load() < 1) {
            Sleep(1000);
            continue;
        }

        // Aumenta il numero di siti simultanei con l'intensità
        numSimultaneous = 1 + (effectIntensity.load() / 3);

        // Corretto il confronto tra tipi diversi
        for (int i = 0; i < numSimultaneous && totalOpened < (int)websites.size(); i++) {
            if (!isRunning) break;

            // Open website
            ShellExecuteA(NULL, "open", websites[totalOpened].c_str(), NULL, NULL, SW_SHOW);
            totalOpened++;

            // Pausa breve tra siti consecutivi nello stesso batch
            Sleep(500);
        }

        // Random delay between batches, più breve con intensità maggiore
        int intensity = effectIntensity.load();
        std::uniform_int_distribution<int> dist(std::max(1000, 4000 - intensity * 300),
                                               std::max(2000, 6000 - intensity * 400));
        Sleep(dist(rng));
    }

    return 0;
}

// Function to open Windows applications
DWORD WINAPI OpenApplicationsThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(10000);

    for (const auto& app : applications) {
        if (!isRunning) break;

        // Aspetta che l'intensità raggiunga almeno 2 prima di iniziare
        if (effectIntensity.load() < 2) {
            Sleep(1000);
            continue;
        }

        // Open application
        ShellExecuteA(NULL, "open", app.c_str(), NULL, NULL, SW_SHOW);

        // Random delay between applications, più breve con intensità maggiore
        int intensity = effectIntensity.load();
        std::uniform_int_distribution<int> dist(std::max(1000, 5000 - intensity * 400),
                                               std::max(2000, 8000 - intensity * 600));
        Sleep(dist(rng));
    }

    return 0;
}

// Random mouse movement
DWORD WINAPI RandomMouseThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(15000);

    while (isRunning) {
        // Attendi che l'intensità sia abbastanza alta
        if (effectIntensity.load() < 3) {
            Sleep(1000);
            continue;
        }

        POINT cursorPos;
        GetCursorPos(&cursorPos);

        // More aggressive mouse movement as intensity increases
        int intensity = std::min(10, effectIntensity.load());
        std::uniform_int_distribution<int> dist(-5 * intensity, 5 * intensity);

        SetCursorPos(cursorPos.x + dist(rng), cursorPos.y + dist(rng));

        // Faster movements as intensity increases
        Sleep(std::max(50, 300 - (intensity * 20)));
    }

    return 0;
}

// Function to show "Still using this computer?" messages
DWORD WINAPI StillUsingThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(20000);

    int messageFrequency = 15000; // Start with 15 seconds
    int messageCount = 0;

    while (isRunning) {
        // Aspetta che l'intensità sia abbastanza alta
        if (effectIntensity.load() < 2) {
            Sleep(1000);
            continue;
        }

        if (!isRunning) break;

        // Show the message box
        MessageBoxA(NULL, "Still using this computer?", "MEMZ Simulator", MB_OK | MB_ICONQUESTION);

        // Increase frequency (reduce time between messages)
        messageFrequency = std::max(1000, messageFrequency - 2000);
        messageCount++;

        Sleep(messageFrequency);
    }

    return 0;
}

// Function to draw error icons under cursor
DWORD WINAPI DrawErrorIconsThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(5000);

    // Load system icons
    HICON errorIcon = LoadIcon(NULL, IDI_ERROR);
    HICON warningIcon = LoadIcon(NULL, IDI_WARNING);
    HICON infoIcon = LoadIcon(NULL, IDI_INFORMATION);

    while (isRunning) {
        // Aspetta che l'intensità sia abbastanza alta
        if (effectIntensity.load() < 1) {
            Sleep(1000);
            continue;
        }

        POINT cursorPos;
        GetCursorPos(&cursorPos);

        // Draw multiple icons based on intensity
        int intensity = effectIntensity.load();
        int numIcons = 1 + intensity / 3;

        for (int i = 0; i < numIcons; i++) {
            // Draw random icons near cursor
            std::uniform_int_distribution<int> iconDist(0, 2);
            std::uniform_int_distribution<int> posDist(-30, 30);

            int iconType = iconDist(rng);
            int offsetX = posDist(rng);
            int offsetY = posDist(rng);

            int x = cursorPos.x + offsetX;
            int y = cursorPos.y + offsetY;

            // Draw the selected icon on screen
            HDC hdcScreen = GetDC(NULL);
            if (iconType == 0) {
                DrawIcon(hdcScreen, x, y, errorIcon);
            } else if (iconType == 1) {
                DrawIcon(hdcScreen, x, y, warningIcon);
            } else {
                DrawIcon(hdcScreen, x, y, infoIcon);
            }
            ReleaseDC(NULL, hdcScreen);

            // Add icon to permanent list (con una certa probabilità)
            if (rand() % 3 == 0) {
                std::lock_guard<std::mutex> lock(iconsMutex);
                PermanentIcon newIcon;
                newIcon.x = x;
                newIcon.y = y;
                newIcon.type = iconType;

                permanentIcons.push_back(newIcon);

                // Limita il numero di icone permanenti
                while (permanentIcons.size() > 200) {
                    permanentIcons.pop_front();
                }
            }
        }

        // Play random error sound with increasing frequency
        if (rand() % (10 - std::min(8, intensity)) == 0) {
            std::uniform_int_distribution<int> soundDist(0, 2);
            int soundType = soundDist(rng);

            if (soundType == 0) {
                PlaySoundA("SystemHand", NULL, SND_ALIAS | SND_ASYNC);
            } else if (soundType == 1) {
                PlaySoundA("SystemQuestion", NULL, SND_ALIAS | SND_ASYNC);
            } else {
                PlaySoundA("SystemExclamation", NULL, SND_ALIAS | SND_ASYNC);
            }
        }

        // More aggressive as intensity increases
        Sleep(std::max(50, 300 - (intensity * 25)));
    }

    // Cleanup
    DestroyIcon(errorIcon);
    DestroyIcon(warningIcon);
    DestroyIcon(infoIcon);

    return 0;
}

// Monitor and update screen captures
DWORD WINAPI ScreenCaptureThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(5000);

    while (isRunning) {
        // Capture current screen
        HBITMAP hCapture = CreateScreenCapture();

        // Add to history and maintain max size
        {
            std::lock_guard<std::mutex> lock(screenCaptureMutex);
            screenHistory.push_front(hCapture);

            // Limit history size
            while (screenHistory.size() > MAX_TUNNEL_WINDOWS) {
                HBITMAP hOld = screenHistory.back();
                screenHistory.pop_back();
                DeleteObject(hOld);
            }
        }

        // Force redraw of all tunnel windows
        {
            std::lock_guard<std::mutex> lock(windowsMutex);
            for (HWND hwnd : createdWindows) {
                InvalidateRect(hwnd, NULL, FALSE);
            }
        }

        // Capture frequency increases with intensity
        int intensity = effectIntensity.load();
        Sleep(std::max(50, 200 - (intensity * 15)));
    }

    // Clean up screen history
    {
        std::lock_guard<std::mutex> lock(screenCaptureMutex);
        for (HBITMAP hBitmap : screenHistory) {
            DeleteObject(hBitmap);
        }
        screenHistory.clear();
    }

    return 0;
}

// Create and manage tunnel windows
DWORD WINAPI TunnelWindowsThread(LPVOID lpParam) {
    HINSTANCE hInstance = (HINSTANCE)lpParam;

    // Wait until we reach intensity level to start tunnel
    while (isRunning && effectIntensity < 4) {
        Sleep(1000);
    }

    tunnelStarted = true;

    // Create multiple tunnel windows progressively
    int maxWindows = MAX_TUNNEL_WINDOWS;
    int currentWindows = 0;

    while (isRunning && currentWindows < maxWindows) {
        // Create a new tunnel window
        HWND hwnd = CreateTunnelWindow(hInstance, currentWindows);

        if (hwnd) {
            std::lock_guard<std::mutex> lock(windowsMutex);
            createdWindows.push_back(hwnd);
            currentWindows++;
        }

        // Increase creation speed with intensity
        int intensity = effectIntensity.load();
        Sleep(std::max(100, 500 - (intensity * 40)));
    }

    // Keep windows alive and occasionally update their appearance
    while (isRunning) {
        {
            std::lock_guard<std::mutex> lock(windowsMutex);
            for (size_t i = 0; i < createdWindows.size(); i++) {
                HWND hwnd = createdWindows[i];

                // Randomly move some windows for chaotic effect
                if (rand() % 5 == 0) {
                    RECT rc;
                    GetWindowRect(hwnd, &rc);

                    std::uniform_int_distribution<int> offsetDist(-20, 20);
                    int newX = rc.left + offsetDist(rng);
                    int newY = rc.top + offsetDist(rng);

                    SetWindowPos(hwnd, NULL, newX, newY, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
                }

                // Force redraw
                InvalidateRect(hwnd, NULL, FALSE);
            }
        }

        Sleep(200);
    }

    // Clean up tunnel windows
    {
        std::lock_guard<std::mutex> lock(windowsMutex);
        for (HWND hwnd : createdWindows) {
            DestroyWindow(hwnd);
        }
        createdWindows.clear();
    }

    return 0;
}

// Function to invert colors on desktop periodically
DWORD WINAPI InvertColorsThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(30000);

    while (isRunning) {
        // Only start inverting after intensity reaches certain level
        if (effectIntensity.load() >= 5) {
            // Invert the entire screen
            HDC hdcScreen = GetDC(NULL);
            BitBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, DSTINVERT);
            ReleaseDC(NULL, hdcScreen);

            // More frequent inversions as intensity increases
            int intensity = effectIntensity.load();
            Sleep(std::max(200, 1000 - (intensity * 80)));
        } else {
            Sleep(1000);
        }
    }

    return 0;
}

// Function to draw GDI chaos directly on desktop
DWORD WINAPI DrawGDIChaosThread(LPVOID lpParam) {
    // Aspetta un po' prima di iniziare (per gradualità)
    Sleep(25000);

    while (isRunning) {
        // Only start drawing after intensity reaches certain level
        int intensity = effectIntensity.load();
        if (intensity >= 6) {
            HDC hdcScreen = GetDC(NULL);
            DrawChaos(hdcScreen, screenWidth, screenHeight);
            ReleaseDC(NULL, hdcScreen);
        }

        // Speed increases with intensity
        Sleep(std::max(50, 300 - (intensity * 25)));
    }

    return 0;
}

// Function to show random error messages
DWORD WINAPI ShowErrorMessagesThread(LPVOID lpParam) {
    // Number of messages to show increases with intensity
    int intensity = std::min(10, effectIntensity.load() + 2);
    int count = intensity;

    std::uniform_int_distribution<int> dist(0, errorMessages.size() - 1);

    for (int i = 0; i < count && isRunning; i++) {
        int index = dist(rng);

        // Set CBT hook to prevent closing these message boxes with Cancel button
        msgBoxHook = SetWindowsHookEx(WH_CBT, CBTProc, NULL, GetCurrentThreadId());

        MessageBoxA(NULL, errorMessages[index].c_str(), "MEMZ Simulator", MB_OK | MB_ICONERROR);

        // Unhook after message box is closed
        if (msgBoxHook != NULL) {
            UnhookWindowsHookEx(msgBoxHook);
            msgBoxHook = NULL;
        }

        if (!isRunning) break;

        Sleep(200);
    }

    return 0;
}

// Function to simulate BSOD
DWORD WINAPI SimulateBSODThread(LPVOID lpParam) {
    // Create a full-screen window
    HWND hWndBSOD = CreateWindowExA(
        WS_EX_TOPMOST,
        "STATIC",
        NULL,
        WS_POPUP | WS_VISIBLE,
        0, 0, screenWidth, screenHeight,
        NULL, NULL, GetModuleHandle(NULL), NULL
    );

    // Set background to blue
    HDC hdc = GetDC(hWndBSOD);
    RECT rc;
    GetClientRect(hWndBSOD, &rc);
    HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 170)); // Blue color
    FillRect(hdc, &rc, hBrush);

    // Add BSOD text
    SetBkColor(hdc, RGB(0, 0, 170));
    SetTextColor(hdc, RGB(255, 255, 255));

    std::string bsodText = "A problem has been detected and Windows has been shut down to prevent damage\r\n";
    bsodText += "to your computer.\r\n\r\n";
    bsodText += "MEMZ_TROJAN\r\n\r\n";
    bsodText += "If this is the first time you've seen this stop error screen,\r\n";
    bsodText += "restart your computer. If this screen appears again, follow\r\n";
    bsodText += "these steps:\r\n\r\n";
    bsodText += "* This is a SAFE SIMULATION. Your computer has not been harmed.\r\n";
    bsodText += "* This window will close automatically after 10 seconds.\r\n";
    bsodText += "* Your real MBR has NOT been overwritten.\r\n\r\n";
    bsodText += "Technical information:\r\n\r\n";
    bsodText += "*** STOP: 0x00000024 (0x00000000, 0x00000000, 0x00000000, 0x00000000)\r\n\r\n";
    bsodText += "Beginning dump of physical memory\r\n";
    bsodText += "Physical memory dump complete.\r\n";
    bsodText += "Contact system administrator or technical support group for further assistance.";

    RECT textRect = {50, 50, rc.right - 50, rc.bottom - 50};
    DrawTextA(hdc, bsodText.c_str(), -1, &textRect, DT_LEFT);

    // Draw some fake memory dump counters
    SetTextColor(hdc, RGB(255, 255, 255));

    for (int i = 0; i < 100 && isRunning; i++) {
        char progress[128];
        sprintf_s(progress, "Dumping physical memory: %d%%", i);

        RECT progressRect = {50, rc.bottom - 100, rc.right - 50, rc.bottom - 50};
        // Clear previous text
        HBRUSH blueBrush = CreateSolidBrush(RGB(0, 0, 170));
        FillRect(hdc, &progressRect, blueBrush);
        DeleteObject(blueBrush);

        // Draw new text
        DrawTextA(hdc, progress, -1, &progressRect, DT_LEFT);
        Sleep(100);
    }

    ReleaseDC(hWndBSOD, hdc);
    DeleteObject(hBrush);

    // Wait for a bit with complete BSOD
    Sleep(5000);

    // Clean up and close
    DestroyWindow(hWndBSOD);

    // Terminate the process
    isRunning = false;

    return 0;
}

// Watchdog thread to monitor termination and trigger chaos
DWORD WINAPI WatchdogThread(LPVOID lpParam) {
    while (isRunning) {
        // Aggiorna l'intensità degli effetti in base al tempo trascorso
        UpdateEffectIntensity();

        // Check if tunnel effect has been running for a while
        static DWORD tunnelStartTime = 0;
        if (tunnelStarted && tunnelStartTime == 0) {
            tunnelStartTime = GetTickCount();
        }

        // After tunnel has run for a certain time, or total duration is reached, move to BSOD
        DWORD elapsedTime = GetTickCount() - programStartTime;
        if ((tunnelStarted && (GetTickCount() - tunnelStartTime > 60000)) ||
            (elapsedTime > TOTAL_DURATION)) {
            // Activate BSOD sequence
            isRunning = false;
            break;
        }

        Sleep(500);
    }

    // If we're here, isRunning is false, but not because of panic button
    if (!panicMode) {
        // Show a few error messages
        HANDLE errorThread = CreateThread(NULL, 0, ShowErrorMessagesThread, NULL, 0, NULL);
        WaitForSingleObject(errorThread, 10000); // Wait for error messages
        CloseHandle(errorThread);

        // Simulate BSOD
        HANDLE bsodThread = CreateThread(NULL, 0, SimulateBSODThread, NULL, 0, NULL);
        WaitForSingleObject(bsodThread, INFINITE);
        CloseHandle(bsodThread);
    }

    return 0;
}

// Cleanup resources
void CleanupResources() {
    isRunning = false;

    // Unhook keyboard
    if (keyboardHook != NULL) {
        UnhookWindowsHookEx(keyboardHook);
        keyboardHook = NULL;
    }

    // Destroy all windows
    {
        std::lock_guard<std::mutex> lock(windowsMutex);
        for (HWND hwnd : createdWindows) {
            DestroyWindow(hwnd);
        }
        createdWindows.clear();
    }

    // Terminate all threads
    for (HANDLE handle : threadHandles) {
        TerminateThread(handle, 0);
        CloseHandle(handle);
    }
    threadHandles.clear();

    // Clean up screen captures
    {
        std::lock_guard<std::mutex> lock(screenCaptureMutex);
        for (HBITMAP hBitmap : screenHistory) {
            DeleteObject(hBitmap);
        }
        screenHistory.clear();
    }

    // Force repaint desktop to remove any artifacts
    InvalidateRect(GetDesktopWindow(), NULL, TRUE);
    UpdateWindow(GetDesktopWindow());
}

// Main function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    // Registra il tempo di inizio del programma
    programStartTime = GetTickCount();

    // Initialize GDI+
    ULONG_PTR gdiplusToken;
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    // Register window classes
    RegisterWindowClasses(hInstance);

    // Set up keyboard hook for panic button (ESC key)
    keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, hInstance, 0);

    // Show warning messages
    bool proceed1 = ShowWarningMessage("WARNING: This program simulates the MEMZ trojan with EXTREME visual effects.\n\n"
                                      "It will demonstrate intense tunnel effects, errors, and screen glitches that look just like the real thing, but will NOT harm your computer.\n\n"
                                      "⚠️ PANIC BUTTON: Press ESC at any time to immediately stop all effects! ⚠️\n\n"
                                      "Do you want to continue?");

    if (!proceed1) {
        CleanupResources();
        return 0;
    }

    bool proceed2 = ShowWarningMessage("FINAL WARNING: This simulation will open multiple windows and websites.\n\n"
                                      "The effects will be EXTREMELY disruptive but temporary and safe.\n\n"
                                      "⚠️ PANIC BUTTON: Press ESC at any time to immediately stop all effects! ⚠️\n\n"
                                      "Are you ABSOLUTELY SURE you want to run this on your computer?");

    if (!proceed2) {
        CleanupResources();
        return 0;
    }

    // Create main hidden window to control the simulation
    controlWindow = CreateWindowA(
        "MEMZSimulatorClass",
        "MEMZ Simulator Control",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 1, 1,
        NULL, NULL, hInstance, NULL
    );

    // Create warning text file
    CreateTextFile();

    // Start watchdog thread
    HANDLE watchdogThread = CreateThread(NULL, 0, WatchdogThread, NULL, 0, NULL);
    threadHandles.push_back(watchdogThread);

    // Start process monitor for BSOD activation
    HANDLE processMonitorThread = CreateThread(NULL, 0, ProcessMonitorThread, NULL, 0, NULL);
    threadHandles.push_back(processMonitorThread);

    // Start all effect threads
    HANDLE websiteThread = CreateThread(NULL, 0, OpenWebsitesThread, NULL, 0, NULL);
    threadHandles.push_back(websiteThread);

    HANDLE appThread = CreateThread(NULL, 0, OpenApplicationsThread, NULL, 0, NULL);
    threadHandles.push_back(appThread);

    HANDLE mouseThread = CreateThread(NULL, 0, RandomMouseThread, NULL, 0, NULL);
    threadHandles.push_back(mouseThread);

    HANDLE usingThread = CreateThread(NULL, 0, StillUsingThread, NULL, 0, NULL);
    threadHandles.push_back(usingThread);

    HANDLE errorIconsThread = CreateThread(NULL, 0, DrawErrorIconsThread, NULL, 0, NULL);
    threadHandles.push_back(errorIconsThread);

    HANDLE captureThread = CreateThread(NULL, 0, ScreenCaptureThread, NULL, 0, NULL);
    threadHandles.push_back(captureThread);

    HANDLE tunnelThread = CreateThread(NULL, 0, TunnelWindowsThread, hInstance, 0, NULL);
    threadHandles.push_back(tunnelThread);

    HANDLE invertThread = CreateThread(NULL, 0, InvertColorsThread, NULL, 0, NULL);
    threadHandles.push_back(invertThread);

    HANDLE chaosThread = CreateThread(NULL, 0, DrawGDIChaosThread, NULL, 0, NULL);
    threadHandles.push_back(chaosThread);

    // Thread per le icone permanenti
    HANDLE permanentIconsThread = CreateThread(NULL, 0, DrawPermanentIconsThread, NULL, 0, NULL);
    threadHandles.push_back(permanentIconsThread);

    // Message loop
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);

        if (!isRunning) {
            break;
        }
    }

    // Clean up
    CleanupResources();

    // Shutdown GDI+
    Gdiplus::GdiplusShutdown(gdiplusToken);

    return 0;
}
