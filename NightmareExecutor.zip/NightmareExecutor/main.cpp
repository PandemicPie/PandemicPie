#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <windows.h>
#include <ws2tcpip.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <gdiplus.h>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <cmath>
#include <thread>
#include <mutex>
#include <random>
#include <chrono>
#include <future>
#include <algorithm>
#include <functional>
#include <Psapi.h>
#include <TlHelp32.h>
#include <Wincrypt.h>
#include <Wininet.h>
#include <Shlwapi.h>
#include <mmsystem.h>
#include <CommCtrl.h>
#include <commdlg.h>
#include <conio.h>
#include <stdarg.h>
#include <inttypes.h>
#include <io.h>
#include <fcntl.h>
#include <direct.h>
#include <sys/stat.h>
#include <sstream>

// Definisci M_PI se non � gi� definito
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Definizione delle costanti di colore personalizzate
#define COLOR_RED Gdiplus::Color(255, 255, 0, 0)
#define COLOR_DARK_RED Gdiplus::Color(255, 120, 0, 0)
#define COLOR_BLACK Gdiplus::Color(255, 0, 0, 0)
#define COLOR_WHITE Gdiplus::Color(255, 255, 255, 255)
#define COLOR_GREEN Gdiplus::Color(255, 0, 255, 0)
#define COLOR_DARK_GREEN Gdiplus::Color(255, 0, 80, 0)
#define COLOR_BLUE Gdiplus::Color(255, 0, 0, 255)
#define COLOR_YELLOW Gdiplus::Color(255, 255, 255, 0)
#define COLOR_GRAY Gdiplus::Color(255, 128, 128, 128)
#define COLOR_PURPLE Gdiplus::Color(255, 128, 0, 128)
#define COLOR_CYAN Gdiplus::Color(255, 0, 255, 255)
#define COLOR_ORANGE Gdiplus::Color(255, 255, 165, 0)
#define COLOR_TRANSPARENT_RED Gdiplus::Color(150, 255, 0, 0)
#define COLOR_TRANSPARENT_BLACK Gdiplus::Color(200, 0, 0, 0)
#define COLOR_HALF_TRANSPARENT_BLACK Gdiplus::Color(128, 0, 0, 0)
#define COLOR_ALMOST_TRANSPARENT_BLACK Gdiplus::Color(80, 0, 0, 0)
#define COLOR_TRANSPARENT_WHITE Gdiplus::Color(100, 255, 255, 255)

// Dimensioni buffer e costanti varie
#define BUFFER_SIZE 8192
#define MAX_LOADSTRING 100
#define MAX_THREADS 16
#define MAX_EFFECTS 24
#define MAX_SIMULATIONS 32
#define SIMULATION_TIMER 240000 // Millisecondi prima del reveal
#define SOUND_INTERVAL 6000     // Intervallo tra suoni inquietanti
#define FLASH_INTERVAL 8000     // Intervallo tra flash violenti
#define GLITCH_INTERVAL 1500    // Intervallo tra glitch
#define SCREEN_INTERVAL 15000   // Intervallo per screenshot falsi
#define MAX_IP_ADDRESSES 1024
#define MAX_PROCESSES 512
#define MAX_FILES 2048
#define MAX_KEYS 512
#define MAX_SERVICES 256
#define MAX_DRIVES 26
#define MAX_ACCOUNTS 32
#define MAX_PASSWORD_LEN 32
#define MAX_USERNAME_LEN 64
#define MAX_HASH_LEN 128
#define MAX_ENCRYPTION_ROUNDS 3
#define MAX_VISUAL_EFFECTS 32
#define MAX_PAYLOADS 64
#define MAX_DESTRUCTION_LEVEL 10
#define PROGRESS_MIN 0
#define PROGRESS_MAX 100
#define MAX_ITERATIONS 50000

// Strutture dati del programma
struct VisualEffect {
    std::string name;
    int priority;
    int intensity;
    int duration;
    std::function<void(HDC, int, int, int)> drawFunction;
};

struct SimulatedFile {
    std::string path;
    std::string originalName;
    bool isEncrypted;
    int size;
    time_t creationTime;
    std::string fileType;
};

struct PayloadInfo {
    std::string name;
    std::string description;
    int severity;
    int executionTime;
    bool isSystemCritical;
    int stage;
    bool executed;
    std::function<void()> simulationFunction;
};

struct NetworkInfo {
    std::string ipAddress;
    std::string macAddress;
    int port;
    std::string protocol;
    bool isVulnerable;
    int packetsSent;
    int packetsReceived;
};

struct SystemProcess {
    std::string name;
    DWORD pid;
    DWORD parentPid;
    int priority;
    std::string user;
    bool isCritical;
    int cpuUsage;
    int memoryUsage;
    std::vector<std::string> modules;
};

struct VirusStats {
    int filesEncrypted;
    int processesInjected;
    int registryKeysModified;
    int accountsCompromised;
    int servicesDisabled;
    int networksCompromised;
    int screenshotsCaptered;
    int passwordsStolen;
    int browsersCleaned;
    int emailsSent;
    int totalDamageCost;
    int systemRebootCount;
};

enum DestructionStage {
    STAGE_INITIALIZATION,
    STAGE_SYSTEM_ANALYSIS,
    STAGE_FILE_ENUMERATION,
    STAGE_NETWORK_SCANNING,
    STAGE_PROCESS_INJECTION,
    STAGE_PERSISTENCE_CREATION,
    STAGE_REGISTRY_MANIPULATION,
    STAGE_SECURITY_BYPASS,
    STAGE_FILE_ENCRYPTION,
    STAGE_RANSOM_PREPARATION,
    STAGE_BOOT_MODIFICATION,
    STAGE_DATA_EXFILTRATION,
    STAGE_BROWSER_HIJACKING,
    STAGE_LATERAL_MOVEMENT,
    STAGE_PRIVILEGE_ESCALATION,
    STAGE_RECOVERY_DISABLING,
    STAGE_FINAL_DESTRUCTION,
    STAGE_CLEANUP,
    STAGE_REVEAL
};

// Variabili globali
std::string tempPath;
std::string logPath;
std::string backupPath;
bool shouldExit = false;
bool revealMode = false;
DestructionStage currentStage = STAGE_INITIALIZATION;
int currentProgress = 0;
int destructionLevel = 0;
int infectedSystems = 0;
int processesTerminated = 0;
int filesBackedUp = 0;
HINSTANCE hInst;
HWND hWndMain = NULL;
HWND hWndProgress = NULL;
HWND hWndRansom = NULL;
ULONG_PTR gdiplusToken;
std::mutex screenMutex;
std::mutex logMutex;
std::vector<std::thread> workerThreads;
std::vector<VisualEffect> visualEffects;
std::vector<PayloadInfo> payloads;
std::vector<SimulatedFile> simulatedFiles;
std::vector<NetworkInfo> simulatedNetworks;
std::vector<SystemProcess> systemProcesses;
VirusStats virusStatistics = {0};
std::mt19937 rng(static_cast<unsigned int>(time(nullptr)));

// Forward declarations di tutte le funzioni
void InitializeNightmareExecutor();
void ShutdownNightmareExecutor();
bool CreateTempDirectory();
bool InitializeLogger();
void LogMessage(const char* format, ...);
void LogError(const char* format, ...);
void LogWarning(const char* format, ...);
void LogSuccess(const char* format, ...);
void LogPayloadExecution(const std::string& payloadName);
void RegisterVisualEffects();
void RegisterPayloads();
void StartWorkerThreads();
void StopWorkerThreads();
void CreateMainWindow();
void UpdateProgressBar(int value);
void ShowRansomwareScreen();
void HideRansomwareScreen();
void CreateFakeBlueScreen();
void CreateFakeBootscreen();
void ShowHackerTerminal();
void SimulateFileEncryption();
void SimulateNetworkScan();
void SimulateProcessInjection();
void SimulateRegistryChanges();
void SimulatePasswordStealing();
void SimulateBrowserHistory();
void SimulateSystemRecoveryDisabling();
void SimulateAntivirusDisabling();
void SimulateFirewallDisabling();
void SimulateScreenCapture();
void SimulateDataExfiltration();
void SimulateBootRecordModification();
void SimulateUserAccountCreation();
void SimulateBitcoinMining();
void SimulateAudioRecording();
void SimulateWebcamCapture();
void SimulateWifiHacking();
void SimulateUsbInfection();
void SimulatePhishingAttack();
void SimulateFileShredding();
void SimulateHardDriveFormatting();
void SimulateSystemMeltdown();
void SimulateKernelPanic();
void SimulateRootkit();
void SimulateRansomwareAttack();
void SimulateBotnetConnection();
void SimulateZeroDay();
void ExecuteNextStage();
void ExecuteRandomPayload();
void DrawVisualEffects();
void DrawBloodDrips(HDC hdc, int width, int height, int intensity);
void DrawStaticNoise(HDC hdc, int width, int height, int intensity);
void DrawGlitchEffect(HDC hdc, int width, int height, int intensity);
void DrawScanlines(HDC hdc, int width, int height, int intensity);
void DrawBinaryRain(HDC hdc, int width, int height, int intensity);
void DrawShatteredScreen(HDC hdc, int width, int height, int intensity);
void DrawSubtleDistortion(HDC hdc, int width, int height, int intensity);
void DrawFlickeringEffect(HDC hdc, int width, int height, int intensity);
void DrawPsychedelicWaves(HDC hdc, int width, int height, int intensity);
void DrawRandomSymbols(HDC hdc, int width, int height, int intensity);
void DrawTunnelEffect(HDC hdc, int width, int height, int intensity);
void DrawMeltingEffect(HDC hdc, int width, int height, int intensity);
void DrawSpinningHypnosis(HDC hdc, int width, int height, int intensity);
void DrawFallingCode(HDC hdc, int width, int height, int intensity);
void DrawSystemError(HDC hdc, int width, int height, int intensity);
void DrawFlashingText(HDC hdc, int width, int height, int intensity);
void DrawInvertedColors(HDC hdc, int width, int height, int intensity);
void GenerateCreepySound(int type);
void GenerateExplosionSound();
void GenerateSystemAlertSound();
void GenerateGlitchSound();
void GenerateErrorBeepSequence();
void GenerateHighPitchedWhine();
void GenerateHeartbeatSound();
void GenerateReverseSound();
void GenerateStaticNoise();
void GenerateWhisperingVoices();
void GenerateCreepyMusic();
void PerformScreenCapture();
void DrawFakeCommandPrompt(HDC hdc, int width, int height);
void PlaySoundResource(int type);
bool BackupSystemSettings();
void RestoreSystemSettings();
void CleanupSimulation();
void RevealPrank();
std::string GenerateRandomFileName();
std::string GenerateRandomIP();
std::string GenerateRandomMAC();
std::string GenerateRandomHash();
std::string GenerateRandomPassword(int length);
std::string GenerateRandomEncryptionExt();
void ShowMessageBoxInfo(const std::string& title, const std::string& message);
void ShowMessageBoxError(const std::string& title, const std::string& message);
void ShowMessageBoxWarning(const std::string& title, const std::string& message);
void SimulateDelayWithProgress(int milliseconds, const std::string& activity);
void IncrementProgress(int amount);
void SetDestructionStage(DestructionStage stage);
int GetRandomValue(int min, int max);
float GetRandomFloat(float min, float max);
void PrintFakeCommandOutput(const std::string& command, int lineCount);
void DisplayCountdown(int seconds, const std::string& message);
void SimulateTypingText(const std::string& text, int delayBetweenChars);
void DrawFakeErrorDialog(HDC hdc, int x, int y, int width, int height, const std::string& errorMessage);
void DrawProgressBar(HDC hdc, int x, int y, int width, int height, int progress, const std::string& text);
void WaitForKeypress();
void ShowFinalStats();
DWORD WINAPI VisualEffectsThread(LPVOID lpParam);
DWORD WINAPI SoundEffectsThread(LPVOID lpParam);
DWORD WINAPI PayloadExecutionThread(LPVOID lpParam);
DWORD WINAPI SimulationTimerThread(LPVOID lpParam);
LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK RansomWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

// Implementazione delle funzioni

void InitializeNightmareExecutor() {
    // Inizializza GDI+
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

    // Crea la directory temporanea e inizializza il logger
    if (!CreateTempDirectory() || !InitializeLogger()) {
        ShowMessageBoxError("Fatal Error", "Failed to initialize NightmareExecutor. Cannot create temporary files.");
        exit(1);
    }

    // Inizializza i generatori di numeri casuali
    srand(static_cast<unsigned int>(time(nullptr)));

    // Registra gli effetti visivi disponibili
    RegisterVisualEffects();

    // Registra i payload da eseguire
    RegisterPayloads();

    // Backup delle impostazioni di sistema (se necessario)
    BackupSystemSettings();

    LogMessage("Initialization complete. NightmareExecutor is ready.");
}

void ShutdownNightmareExecutor() {
    // Ferma i thread di lavoro
    StopWorkerThreads();

    // Restore delle impostazioni di sistema (se necessario)
    if (!revealMode) {
        RestoreSystemSettings();
    }

    // Pulizia GDI+
    Gdiplus::GdiplusShutdown(gdiplusToken);

    LogMessage("NightmareExecutor shutdown complete.");
}

bool CreateTempDirectory() {
    char tempPathBuffer[MAX_PATH];
    GetTempPath(MAX_PATH, tempPathBuffer);
    tempPath = std::string(tempPathBuffer) + "NightmareExecutor\\";
    backupPath = tempPath + "Backup\\";
    logPath = tempPath + "Logs\\";

    // Crea la directory temporanea
    if (!CreateDirectory(tempPath.c_str(), NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
        return false;
    }

    // Crea la directory di backup
    if (!CreateDirectory(backupPath.c_str(), NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
        return false;
    }

    // Crea la directory di log
    if (!CreateDirectory(logPath.c_str(), NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
        return false;
    }

    return true;
}

bool InitializeLogger() {
    std::string logFilePath = logPath + "nightmare.log";
    std::ofstream logFile(logFilePath, std::ios::out | std::ios::trunc);
    if (!logFile.is_open()) {
        return false;
    }

    logFile << "[" << time(nullptr) << "] NightmareExecutor logging initialized.\n";
    logFile.close();

    return true;
}

void LogMessage(const char* format, ...) {
    std::lock_guard<std::mutex> lock(logMutex);

    va_list args;
    va_start(args, format);

    char buffer[BUFFER_SIZE];
    vsnprintf(buffer, BUFFER_SIZE, format, args);

    std::string logFilePath = logPath + "nightmare.log";
    std::ofstream logFile(logFilePath, std::ios::out | std::ios::app);
    if (logFile.is_open()) {
        logFile << "[" << time(nullptr) << "] INFO: " << buffer << std::endl;
        logFile.close();
    }

    va_end(args);
}

void LogError(const char* format, ...) {
    std::lock_guard<std::mutex> lock(logMutex);

    va_list args;
    va_start(args, format);

    char buffer[BUFFER_SIZE];
    vsnprintf(buffer, BUFFER_SIZE, format, args);

    std::string logFilePath = logPath + "nightmare.log";
    std::ofstream logFile(logFilePath, std::ios::out | std::ios::app);
    if (logFile.is_open()) {
        logFile << "[" << time(nullptr) << "] ERROR: " << buffer << std::endl;
        logFile.close();
    }

    va_end(args);
}

void LogWarning(const char* format, ...) {
    std::lock_guard<std::mutex> lock(logMutex);

    va_list args;
    va_start(args, format);

    char buffer[BUFFER_SIZE];
    vsnprintf(buffer, BUFFER_SIZE, format, args);

    std::string logFilePath = logPath + "nightmare.log";
    std::ofstream logFile(logFilePath, std::ios::out | std::ios::app);
    if (logFile.is_open()) {
        logFile << "[" << time(nullptr) << "] WARNING: " << buffer << std::endl;
        logFile.close();
    }

    va_end(args);
}

void LogSuccess(const char* format, ...) {
    std::lock_guard<std::mutex> lock(logMutex);

    va_list args;
    va_start(args, format);

    char buffer[BUFFER_SIZE];
    vsnprintf(buffer, BUFFER_SIZE, format, args);

    std::string logFilePath = logPath + "nightmare.log";
    std::ofstream logFile(logFilePath, std::ios::out | std::ios::app);
    if (logFile.is_open()) {
        logFile << "[" << time(nullptr) << "] SUCCESS: " << buffer << std::endl;
        logFile.close();
    }

    va_end(args);
}

void LogPayloadExecution(const std::string& payloadName) {
    std::lock_guard<std::mutex> lock(logMutex);

    std::string logFilePath = logPath + "payloads.log";
    std::ofstream logFile(logFilePath, std::ios::out | std::ios::app);
    if (logFile.is_open()) {
        logFile << "[" << time(nullptr) << "] EXECUTED: " << payloadName << std::endl;
        logFile.close();
    }
}

void RegisterVisualEffects() {
    // Registra tutti gli effetti visivi disponibili
    visualEffects.clear();

    visualEffects.push_back({"BloodDrips", 5, 100, 500, DrawBloodDrips});
    visualEffects.push_back({"StaticNoise", 4, 60, 200, DrawStaticNoise});
    visualEffects.push_back({"GlitchEffect", 8, 80, 300, DrawGlitchEffect});
    visualEffects.push_back({"Scanlines", 3, 70, 1000, DrawScanlines});
    visualEffects.push_back({"BinaryRain", 6, 50, 1500, DrawBinaryRain});
    visualEffects.push_back({"ShatteredScreen", 9, 90, 2000, DrawShatteredScreen});
    visualEffects.push_back({"SubtleDistortion", 2, 40, 1000, DrawSubtleDistortion});
    visualEffects.push_back({"FlickeringEffect", 7, 85, 500, DrawFlickeringEffect});
    visualEffects.push_back({"PsychedelicWaves", 6, 60, 800, DrawPsychedelicWaves});
    visualEffects.push_back({"RandomSymbols", 4, 40, 700, DrawRandomSymbols});
    visualEffects.push_back({"TunnelEffect", 8, 75, 1200, DrawTunnelEffect});
    visualEffects.push_back({"MeltingEffect", 9, 85, 1500, DrawMeltingEffect});
    visualEffects.push_back({"SpinningHypnosis", 7, 65, 900, DrawSpinningHypnosis});
    visualEffects.push_back({"FallingCode", 5, 55, 600, DrawFallingCode});
    visualEffects.push_back({"SystemError", 10, 95, 1800, DrawSystemError});
    visualEffects.push_back({"FlashingText", 8, 80, 1000, DrawFlashingText});
    visualEffects.push_back({"InvertedColors", 7, 70, 1200, DrawInvertedColors});

    LogMessage("Registered %d visual effects.", visualEffects.size());
}

void RegisterPayloads() {
    // Registra tutti i payload disponibili
    payloads.clear();

    payloads.push_back({"FileEncryption", "Encrypts user files", 9, 8000, true, STAGE_FILE_ENCRYPTION, false, SimulateFileEncryption});
    payloads.push_back({"NetworkScan", "Scans for vulnerable machines", 5, 5000, false, STAGE_NETWORK_SCANNING, false, SimulateNetworkScan});
    payloads.push_back({"ProcessInjection", "Injects malicious code into processes", 8, 6000, true, STAGE_PROCESS_INJECTION, false, SimulateProcessInjection});
    payloads.push_back({"RegistryChanges", "Modifies system registry", 7, 4000, true, STAGE_REGISTRY_MANIPULATION, false, SimulateRegistryChanges});
    payloads.push_back({"PasswordStealing", "Steals user passwords", 9, 7000, false, STAGE_DATA_EXFILTRATION, false, SimulatePasswordStealing});
    payloads.push_back({"BrowserHistory", "Steals browser history and cookies", 7, 5500, false, STAGE_BROWSER_HIJACKING, false, SimulateBrowserHistory});
    payloads.push_back({"SystemRecoveryDisabling", "Disables system recovery functions", 10, 9000, true, STAGE_RECOVERY_DISABLING, false, SimulateSystemRecoveryDisabling});
    payloads.push_back({"AntivirusDisabling", "Disables antivirus protection", 9, 7500, true, STAGE_SECURITY_BYPASS, false, SimulateAntivirusDisabling});
    payloads.push_back({"FirewallDisabling", "Disables system firewall", 8, 6500, true, STAGE_SECURITY_BYPASS, false, SimulateFirewallDisabling});
    payloads.push_back({"ScreenCapture", "Captures screen content", 6, 4500, false, STAGE_DATA_EXFILTRATION, false, SimulateScreenCapture});
    payloads.push_back({"DataExfiltration", "Sends user data to remote servers", 9, 8500, false, STAGE_DATA_EXFILTRATION, false, SimulateDataExfiltration});
    payloads.push_back({"BootRecordModification", "Modifies the boot record", 10, 10000, true, STAGE_BOOT_MODIFICATION, false, SimulateBootRecordModification});
    payloads.push_back({"UserAccountCreation", "Creates backdoor user accounts", 8, 7000, true, STAGE_PRIVILEGE_ESCALATION, false, SimulateUserAccountCreation});
    payloads.push_back({"BitcoinMining", "Uses system resources for crypto mining", 7, 6000, false, STAGE_SYSTEM_ANALYSIS, false, SimulateBitcoinMining});
    payloads.push_back({"AudioRecording", "Records audio from microphone", 8, 7000, false, STAGE_DATA_EXFILTRATION, false, SimulateAudioRecording});
    payloads.push_back({"WebcamCapture", "Captures images from webcam", 9, 7500, false, STAGE_DATA_EXFILTRATION, false, SimulateWebcamCapture});
    payloads.push_back({"WifiHacking", "Hacks nearby wifi networks", 7, 8000, false, STAGE_LATERAL_MOVEMENT, false, SimulateWifiHacking});
    payloads.push_back({"UsbInfection", "Infects connected USB devices", 8, 6500, false, STAGE_LATERAL_MOVEMENT, false, SimulateUsbInfection});
    payloads.push_back({"PhishingAttack", "Sets up fake login screens", 7, 5000, false, STAGE_DATA_EXFILTRATION, false, SimulatePhishingAttack});
    payloads.push_back({"FileShredding", "Permanently deletes sensitive files", 9, 8000, true, STAGE_FINAL_DESTRUCTION, false, SimulateFileShredding});
    payloads.push_back({"HardDriveFormatting", "Formats system drive", 10, 12000, true, STAGE_FINAL_DESTRUCTION, false, SimulateHardDriveFormatting});
    payloads.push_back({"SystemMeltdown", "Causes system to crash and malfunction", 10, 10000, true, STAGE_FINAL_DESTRUCTION, false, SimulateSystemMeltdown});
    payloads.push_back({"KernelPanic", "Induces kernel panic", 10, 9000, true, STAGE_FINAL_DESTRUCTION, false, SimulateKernelPanic});
    payloads.push_back({"Rootkit", "Installs persistent rootkit", 9, 9500, true, STAGE_PERSISTENCE_CREATION, false, SimulateRootkit});
    payloads.push_back({"RansomwareAttack", "Encrypts files and demands ransom", 10, 11000, true, STAGE_RANSOM_PREPARATION, false, SimulateRansomwareAttack});
    payloads.push_back({"BotnetConnection", "Connects to botnet command servers", 8, 7000, false, STAGE_LATERAL_MOVEMENT, false, SimulateBotnetConnection});
    payloads.push_back({"ZeroDay", "Exploits zero-day vulnerability", 10, 10000, true, STAGE_SECURITY_BYPASS, false, SimulateZeroDay});

    LogMessage("Registered %d payload modules.", payloads.size());
}

void StartWorkerThreads() {
    // Crea thread per effetti visivi
    workerThreads.push_back(std::thread([]() {
        VisualEffectsThread(nullptr);
    }));

    // Crea thread per effetti sonori
    workerThreads.push_back(std::thread([]() {
        SoundEffectsThread(nullptr);
    }));

    // Crea thread per l'esecuzione dei payload
    workerThreads.push_back(std::thread([]() {
        PayloadExecutionThread(nullptr);
    }));

    // Crea thread per il timer di simulazione
    workerThreads.push_back(std::thread([]() {
        SimulationTimerThread(nullptr);
    }));

    LogMessage("Started %d worker threads.", workerThreads.size());
}

void StopWorkerThreads() {
    shouldExit = true;

    // Attendi la terminazione di tutti i thread
    for (auto& thread : workerThreads) {
        if (thread.joinable()) {
            thread.join();
        }
    }

    workerThreads.clear();
    LogMessage("Stopped all worker threads.");
}

void CreateMainWindow() {
    // Registrazione della classe della finestra
    WNDCLASSEX wcex;
    ZeroMemory(&wcex, sizeof(WNDCLASSEX));
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = MainWndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInst;
    wcex.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = nullptr;
    wcex.lpszClassName = "NightmareExecutorClass";
    wcex.hIconSm = LoadIcon(nullptr, IDI_APPLICATION);

    if (!RegisterClassEx(&wcex)) {
        LogError("Failed to register window class: %d", GetLastError());
        return;
    }

    // Creazione della finestra principale (nascosta)
    hWndMain = CreateWindow(
        "NightmareExecutorClass",
        "NightmareExecutor",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT,
        800, 600,
        nullptr, nullptr, hInst, nullptr);

    if (!hWndMain) {
        LogError("Failed to create main window: %d", GetLastError());
        return;
    }

    // Non mostrare la finestra, ma mantenere attivo il thread di messaggi
    // ShowWindow(hWndMain, SW_SHOW);
    // UpdateWindow(hWndMain);

    LogMessage("Main window created (hidden).");
}

void UpdateProgressBar(int value) {
    if (hWndProgress) {
        SendMessage(hWndProgress, PBM_SETPOS, value, 0);
    }
}

void ShowRansomwareScreen() {
    // Registrazione della classe della finestra
    WNDCLASSEX wcex;
    ZeroMemory(&wcex, sizeof(WNDCLASSEX));
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = RansomWndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInst;
    wcex.hIcon = LoadIcon(nullptr, IDI_ERROR);
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = CreateSolidBrush(RGB(30, 30, 30));
    wcex.lpszMenuName = nullptr;
    wcex.lpszClassName = "RansomWindowClass";
    wcex.hIconSm = LoadIcon(nullptr, IDI_ERROR);

    if (!RegisterClassEx(&wcex)) {
        LogError("Failed to register ransom window class: %d", GetLastError());
        return;
    }

    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Creazione della finestra di riscatto (a schermo intero)
    hWndRansom = CreateWindowEx(
        WS_EX_TOPMOST,
        "RansomWindowClass",
        "YOUR FILES HAVE BEEN ENCRYPTED",
        WS_POPUP | WS_VISIBLE,
        0, 0, screenWidth, screenHeight,
        nullptr, nullptr, hInst, nullptr);

    if (!hWndRansom) {
        LogError("Failed to create ransom window: %d", GetLastError());
        return;
    }

    // Mostra la finestra di riscatto
    ShowWindow(hWndRansom, SW_SHOW);
    UpdateWindow(hWndRansom);

    LogMessage("Ransom screen displayed.");
}

void HideRansomwareScreen() {
    if (hWndRansom) {
        DestroyWindow(hWndRansom);
        hWndRansom = NULL;
    }
}

void CreateFakeBlueScreen() {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);
    SelectObject(hdcMem, hbmScreen);

    // Disegna sfondo blu
    RECT rect = {0, 0, screenWidth, screenHeight};
    HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 128));
    FillRect(hdcMem, &rect, hBrush);
    DeleteObject(hBrush);

    // Setta il font per il testo
    HFONT hFont = CreateFont(24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                             ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
    SelectObject(hdcMem, hFont);
    SetBkColor(hdcMem, RGB(0, 0, 128));
    SetTextColor(hdcMem, RGB(255, 255, 255));

    // Testo del BSOD
    std::string bsodText =
        "A problem has been detected and Windows has been shut down to prevent damage\n"
        "to your computer.\n\n"
        "CRITICAL_PROCESS_DIED\n\n"
        "If this is the first time you've seen this stop error screen,\n"
        "restart your computer. If this screen appears again, follow\n"
        "these steps:\n\n"
        "Check for viruses on your computer. Remove any newly installed\n"
        "hard drives or hard drive controllers. Check your hard drive\n"
        "to make sure it is properly configured and terminated.\n"
        "Run CHKDSK /F to check for hard drive corruption, and then\n"
        "restart your computer.\n\n"
        "Technical information:\n\n"
        "*** STOP: 0x000000EF (0x00000000, 0x00000000, 0x00000000, 0x00000000)\n\n"
        "Collecting data for crash dump ...\n"
        "Initializing disk for crash dump ...\n"
        "Physical memory dump complete.\n"
        "Contact your system administrator or technical support group for further\n"
        "assistance.";

    // Spezza il testo in righe
    std::vector<std::string> lines;
    std::string line;
    std::istringstream iss(bsodText);
    while (std::getline(iss, line)) {
        lines.push_back(line);
    }

    // Disegna le righe di testo
    int y = 100;
    for (const auto& textLine : lines) {
        TextOut(hdcMem, 100, y, textLine.c_str(), textLine.length());
        y += 30;
    }

    // Copia l'immagine sullo schermo
    BitBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcMem, 0, 0, SRCCOPY);

    // Pulizia
    DeleteObject(hFont);
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    LogMessage("Fake Blue Screen displayed.");

    // Pausa per visualizzare il BSOD
    Sleep(5000);
}

void CreateFakeBootscreen() {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);
    SelectObject(hdcMem, hbmScreen);

    // Disegna sfondo nero
    RECT rect = {0, 0, screenWidth, screenHeight};
    HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(hdcMem, &rect, hBrush);
    DeleteObject(hBrush);

    // Setta il font per il testo
    HFONT hFont = CreateFont(24, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                             ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
    SelectObject(hdcMem, hFont);
    SetBkColor(hdcMem, RGB(0, 0, 0));
    SetTextColor(hdcMem, RGB(255, 255, 255));

    // Carica il logo di Windows (simulato)
    int logoWidth = 200;
    int logoHeight = 200;
    int logoX = (screenWidth - logoWidth) / 2;
    int logoY = (screenHeight - logoHeight) / 2 - 50;

    // Disegna cerchio come logo
    HBRUSH hLogoBrush = CreateSolidBrush(RGB(0, 120, 215));
    HPEN hLogoPen = CreatePen(PS_SOLID, 2, RGB(0, 120, 215));
    SelectObject(hdcMem, hLogoBrush);
    SelectObject(hdcMem, hLogoPen);
    Ellipse(hdcMem, logoX, logoY, logoX + logoWidth, logoY + logoHeight);
    DeleteObject(hLogoBrush);
    DeleteObject(hLogoPen);

    // Aggiungi un'icona di caricamento (cerchio che ruota)
    int spinnerRadius = 15;
    int spinnerX = screenWidth / 2;
    int spinnerY = (screenHeight + logoHeight) / 2 + 100;

    // Simula l'animazione del cerchio che ruota
    for (int i = 0; i < 360; i += 30) {
        // Cancella il disegno precedente
        HBRUSH hBgBrush = CreateSolidBrush(RGB(0, 0, 0));
        RECT spinnerRect = {spinnerX - spinnerRadius - 5, spinnerY - spinnerRadius - 5,
                            spinnerX + spinnerRadius + 5, spinnerY + spinnerRadius + 5};
        FillRect(hdcMem, &spinnerRect, hBgBrush);
        DeleteObject(hBgBrush);

        // Calcola il punto sul cerchio
        int dotX = spinnerX + static_cast<int>(spinnerRadius * cos(i * M_PI / 180));
        int dotY = spinnerY + static_cast<int>(spinnerRadius * sin(i * M_PI / 180));

        // Disegna il punto
        HBRUSH hDotBrush = CreateSolidBrush(RGB(255, 255, 255));
        HPEN hDotPen = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
        SelectObject(hdcMem, hDotBrush);
        SelectObject(hdcMem, hDotPen);
        Ellipse(hdcMem, dotX - 3, dotY - 3, dotX + 3, dotY + 3);
        DeleteObject(hDotBrush);
        DeleteObject(hDotPen);

        // Disegna un testo per indicare che Windows ha un problema
        std::string bootText;
        if (i < 90) {
            bootText = "Your PC ran into a problem and needs to restart.";
        } else if (i < 180) {
            bootText = "We're just collecting some error info, and then we'll restart for you.";
        } else if (i < 270) {
            bootText = "0% complete";
        } else {
            bootText = "CRITICAL SYSTEM ERROR: Boot sector compromised";
        }

        RECT textRect = {0, spinnerY + spinnerRadius + 20, screenWidth, spinnerY + spinnerRadius + 50};
        DrawText(hdcMem, bootText.c_str(), bootText.length(), &textRect, DT_CENTER);

        // Copia l'immagine sullo schermo
        BitBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcMem, 0, 0, SRCCOPY);

        // Pausa breve per l'animazione
        Sleep(500);
    }

    // Pulizia
    DeleteObject(hFont);
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    LogMessage("Fake Boot Screen displayed.");
}

void ShowHackerTerminal() {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);
    SelectObject(hdcMem, hbmScreen);

    // Disegna sfondo nero
    RECT rect = {0, 0, screenWidth, screenHeight};
    HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(hdcMem, &rect, hBrush);
    DeleteObject(hBrush);

    // Setta il font per il testo
    HFONT hFont = CreateFont(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                             ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                             DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Consolas");
    SelectObject(hdcMem, hFont);
    SetBkColor(hdcMem, RGB(0, 0, 0));
    SetTextColor(hdcMem, RGB(0, 255, 0));

    // Testo del terminale hacker
    std::vector<std::string> commands = {
        "root@darknet:~# ./exploit.sh -t %s -p 22 --force",
        "Scanning target system...",
        "Vulnerability CVE-2023-65432 found!",
        "Exploiting vulnerability...",
        "Remote shell established",
        "root@%s:~# whoami",
        "SYSTEM",
        "root@%s:~# ls -la /",
        "drwxr-xr-x 2 root root 4096 Documents",
        "drwxr-xr-x 2 root root 4096 Downloads",
        "drwxr-xr-x 2 root root 4096 Pictures",
        "drwxr-xr-x 2 root root 4096 Windows",
        "root@%s:~# cd Windows/System32",
        "root@%s:/Windows/System32# ls -la",
        "drwxr-xr-x 2 root root 4096 kernel32.dll",
        "drwxr-xr-x 2 root root 4096 user32.dll",
        "drwxr-xr-x 2 root root 4096 ntdll.dll",
        "root@%s:/Windows/System32# ./encrypt_all.sh --no-backup",
        "Encrypting system files...",
        "Encrypting user files...",
        "Installing bootkit...",
        "Setting up persistence...",
        "Disabling security...",
        "root@%s:/Windows/System32# reboot",
        "System will now reboot into NIGHTMARE mode..."
    };

    // Ottiene l'indirizzo IP locale
    char hostname[256];
    gethostname(hostname, sizeof(hostname));
    struct hostent* he = gethostbyname(hostname);
    const char* localIP = "127.0.0.1";
    if (he != nullptr) {
        if (he->h_addr_list[0] != nullptr) {
            struct in_addr addr;
            addr.s_addr = *(u_long*)he->h_addr_list[0];
            localIP = inet_ntoa(addr);
        }
    }

    // Disegna le righe di testo una per una, con effetto di battitura
    int y = 50;
    for (const auto& cmd : commands) {
        char buffer[256];
        snprintf(buffer, sizeof(buffer), cmd.c_str(), localIP, localIP, localIP, localIP, localIP, localIP);
        std::string command = buffer;

        // Simula la battitura carattere per carattere
        for (size_t i = 0; i <= command.length(); i++) {
            // Aggiorna il testo visualizzato
            TextOut(hdcMem, 50, y, command.substr(0, i).c_str(), i);

            // Copia l'immagine sullo schermo
            BitBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcMem, 0, 0, SRCCOPY);

            // Pausa breve per simulare la battitura
            Sleep(GetRandomValue(10, 50));
        }

        y += 24;
        Sleep(GetRandomValue(200, 800));
    }

    // Pulizia
    DeleteObject(hFont);
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);

    LogMessage("Hacker Terminal simulation displayed.");
}

// ... Implementazione di tutte le funzioni di simulazione payload

void SimulateFileEncryption() {
    LogMessage("Executing FileEncryption payload...");

    // Ottiene l'elenco delle directory utente
    char documentsPath[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_PERSONAL, NULL, 0, documentsPath);

    char picturesPath[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_MYPICTURES, NULL, 0, picturesPath);

    char desktopPath[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_DESKTOP, NULL, 0, desktopPath);

    // Simula la cifratura dei file nelle directory comuni
    std::vector<std::string> directories = {
        documentsPath,
        picturesPath,
        desktopPath
    };

    // Estensioni di file da "cifrare"
    std::vector<std::string> extensions = {
        ".docx", ".xlsx", ".pptx", ".pdf", ".jpg", ".png", ".mp3", ".mp4",
        ".txt", ".zip", ".rar", ".psd", ".html", ".css", ".js", ".cpp", ".h"
    };

    // Crea file di simulazione nella cartella temporanea
    int filesEncrypted = GetRandomValue(100, 500);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Crea un DC per GDI+
    Gdiplus::Graphics graphics(memDC);

    // Disegna un overlay semi-trasparente
    Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
    graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

    for (int i = 0; i < filesEncrypted; i++) {
        // Genera un percorso file casuale
        std::string directory = directories[rand() % directories.size()];
        std::string extension = extensions[rand() % extensions.size()];
        std::string fileName = GenerateRandomFileName() + extension;
        std::string fullPath = directory + "\\" + fileName;

        // Crea un file finto nella cartella temporanea per tenere traccia
        std::string encryptedFileName = GenerateRandomFileName() + ".encrypted";
        std::string tempFilePath = tempPath + encryptedFileName;

        // Aggiungi alla lista dei file simulati
        SimulatedFile simFile;
        simFile.path = tempFilePath;
        simFile.originalName = fullPath;
        simFile.isEncrypted = true;
        simFile.size = GetRandomValue(1024, 10 * 1024 * 1024);
        simFile.creationTime = time(nullptr);
        simFile.fileType = extension;
        simulatedFiles.push_back(simFile);

        // Aggiorna le statistiche
        virusStatistics.filesEncrypted++;

        // Disegna la progress bar
        int progress = (i * 100) / filesEncrypted;

        Gdiplus::SolidBrush bgBrush(COLOR_TRANSPARENT_BLACK);
        graphics.FillRectangle(&bgBrush, screenWidth / 4, screenHeight / 2 - 40, screenWidth / 2, 80);

        Gdiplus::SolidBrush textBrush(COLOR_WHITE);
        Gdiplus::Font font(L"Arial", 12);
        Gdiplus::StringFormat format;
        format.SetAlignment(Gdiplus::StringAlignmentCenter);

        std::wstring statusText = L"Encrypting files: " + std::to_wstring(i) + L" of " + std::to_wstring(filesEncrypted);
        std::wstring fileText = std::wstring(fullPath.begin(), fullPath.end());
        if (fileText.length() > 50) {
            fileText = L"..." + fileText.substr(fileText.length() - 50);
        }

        Gdiplus::RectF textRect(screenWidth / 4, screenHeight / 2 - 40, screenWidth / 2, 25);
        graphics.DrawString(statusText.c_str(), -1, &font, textRect, &format, &textBrush);

        Gdiplus::RectF fileRect(screenWidth / 4, screenHeight / 2 - 15, screenWidth / 2, 25);
        graphics.DrawString(fileText.c_str(), -1, &font, fileRect, &format, &textBrush);

        // Disegna la barra di progresso
        Gdiplus::RectF progressRect(screenWidth / 4, screenHeight / 2 + 15, screenWidth / 2, 20);
        Gdiplus::SolidBrush progressBgBrush(COLOR_GRAY);
        graphics.FillRectangle(&progressBgBrush, progressRect);

        Gdiplus::RectF progressFillRect(screenWidth / 4, screenHeight / 2 + 15, (screenWidth / 2) * progress / 100, 20);
        Gdiplus::SolidBrush progressFillBrush(COLOR_RED);
        graphics.FillRectangle(&progressFillBrush, progressFillRect);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Breve pausa per visualizzare l'avanzamento
        Sleep(50);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);

    LogSuccess("FileEncryption payload completed: %d files encrypted", filesEncrypted);
}

void SimulateNetworkScan() {
    LogMessage("Executing NetworkScan payload...");

    // Ottiene l'indirizzo IP locale
    char hostname[256];
    gethostname(hostname, sizeof(hostname));
    struct hostent* he = gethostbyname(hostname);
    const char* localIP = "127.0.0.1";
    if (he != nullptr) {
        if (he->h_addr_list[0] != nullptr) {
            struct in_addr addr;
            addr.s_addr = *(u_long*)he->h_addr_list[0];
            localIP = inet_ntoa(addr);
        }
    }

    // Estrae il prefisso della rete
    std::string networkPrefix = std::string(localIP);
    size_t lastDot = networkPrefix.find_last_of('.');
    if (lastDot != std::string::npos) {
        networkPrefix = networkPrefix.substr(0, lastDot + 1);
    }

    // Simula scansione di rete
    int totalHosts = GetRandomValue(20, 100);
    int vulnerableHosts = GetRandomValue(5, 15);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Crea un DC per GDI+
    Gdiplus::Graphics graphics(memDC);

    // Disegna un overlay semi-trasparente
    Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
    graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

    // Specifica i servizi da "scansionare"
    std::vector<std::string> services = {
        "SSH (22/tcp)", "FTP (21/tcp)", "Telnet (23/tcp)", "SMTP (25/tcp)",
        "HTTP (80/tcp)", "HTTPS (443/tcp)", "SMB (445/tcp)", "RDP (3389/tcp)"
    };

    // Simula la scansione di ogni host
    for (int i = 1; i <= totalHosts; i++) {
        // Genera un indirizzo IP casuale nella stessa rete
        std::string ip = networkPrefix + std::to_string(GetRandomValue(1, 254));

        // Genera un MAC address casuale
        std::string mac = GenerateRandomMAC();

        // Determina se l'host � vulnerabile
        bool isVulnerable = (i % (totalHosts / vulnerableHosts) == 0);

        // Genera informazioni di rete
        NetworkInfo netInfo;
        netInfo.ipAddress = ip;
        netInfo.macAddress = mac;

        // Estrai la porta come numero (gestione diversa per MinGW)
        if (isVulnerable) {
            std::string serviceStr = services[rand() % services.size()];
            size_t pos1 = serviceStr.find('(');
            size_t pos2 = serviceStr.find('/');
            if (pos1 != std::string::npos && pos2 != std::string::npos && pos1 < pos2) {
                std::string portStr = serviceStr.substr(pos1 + 1, pos2 - pos1 - 1);
                netInfo.port = atoi(portStr.c_str());
            } else {
                netInfo.port = 0; // Default se non si riesce a estrarre
            }
        } else {
            netInfo.port = 0;
        }

        netInfo.protocol = "TCP";
        netInfo.isVulnerable = isVulnerable;
        netInfo.packetsSent = GetRandomValue(10, 100);
        netInfo.packetsReceived = GetRandomValue(5, netInfo.packetsSent);

        // Aggiungi alla lista delle reti simulate
        simulatedNetworks.push_back(netInfo);

        // Aggiorna le statistiche
        if (isVulnerable) {
            virusStatistics.networksCompromised++;
        }

        // Disegna la progress bar
        int progress = (i * 100) / totalHosts;

        Gdiplus::SolidBrush bgBrush(COLOR_TRANSPARENT_BLACK);
        graphics.FillRectangle(&bgBrush, screenWidth / 4, screenHeight / 2 - 60, screenWidth / 2, 120);

        Gdiplus::SolidBrush textBrush(COLOR_GREEN);
        Gdiplus::Font font(L"Consolas", 12);
        Gdiplus::StringFormat format;
        format.SetAlignment(Gdiplus::StringAlignmentCenter);

        std::wstring statusText = L"Network Scan in Progress: " + std::to_wstring(i) + L" of " + std::to_wstring(totalHosts);
        std::wstring hostText = L"Scanning host: " + std::wstring(ip.begin(), ip.end()) + L" [" + std::wstring(mac.begin(), mac.end()) + L"]";
        std::wstring vulnText = isVulnerable ? L"VULNERABLE!" : L"No vulnerabilities found";

        Gdiplus::RectF statusRect(screenWidth / 4, screenHeight / 2 - 60, screenWidth / 2, 25);
        graphics.DrawString(statusText.c_str(), -1, &font, statusRect, &format, &textBrush);

        Gdiplus::RectF hostRect(screenWidth / 4, screenHeight / 2 - 35, screenWidth / 2, 25);
        graphics.DrawString(hostText.c_str(), -1, &font, hostRect, &format, &textBrush);

        Gdiplus::RectF vulnRect(screenWidth / 4, screenHeight / 2 - 10, screenWidth / 2, 25);
        Gdiplus::SolidBrush vulnBrush(isVulnerable ? COLOR_RED : COLOR_GREEN);
        graphics.DrawString(vulnText.c_str(), -1, &font, vulnRect, &format, &vulnBrush);

        // Disegna la barra di progresso
        Gdiplus::RectF progressRect(screenWidth / 4, screenHeight / 2 + 20, screenWidth / 2, 20);
        Gdiplus::SolidBrush progressBgBrush(COLOR_GRAY);
        graphics.FillRectangle(&progressBgBrush, progressRect);

        Gdiplus::RectF progressFillRect(screenWidth / 4, screenHeight / 2 + 20, (screenWidth / 2) * progress / 100, 20);
        Gdiplus::SolidBrush progressFillBrush(COLOR_GREEN);
        graphics.FillRectangle(&progressFillBrush, progressFillRect);

        // Aggiungi un testo per vulnerabili trovati
        std::wstring foundText = L"Vulnerable hosts found: " + std::to_wstring(virusStatistics.networksCompromised);
        Gdiplus::RectF foundRect(screenWidth / 4, screenHeight / 2 + 45, screenWidth / 2, 25);
        graphics.DrawString(foundText.c_str(), -1, &font, foundRect, &format, &textBrush);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Breve pausa per visualizzare l'avanzamento
        Sleep(100);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);

    LogSuccess("NetworkScan payload completed: %d hosts scanned, %d vulnerable hosts found",
              totalHosts, virusStatistics.networksCompromised);
}

void SimulateProcessInjection() {
    LogMessage("Executing ProcessInjection payload...");

    // Ottiene l'elenco dei processi in esecuzione
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        LogError("Failed to create process snapshot: %d", GetLastError());
        return;
    }

    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);

    std::vector<PROCESSENTRY32> processes;

    if (Process32First(hSnapshot, &pe32)) {
        do {
            processes.push_back(pe32);
        } while (Process32Next(hSnapshot, &pe32));
    }

    CloseHandle(hSnapshot);

    // Processi di sistema importanti da "infettare"
    std::vector<std::string> importantProcesses = {
        "explorer.exe", "svchost.exe", "lsass.exe", "services.exe",
        "winlogon.exe", "csrss.exe", "spoolsv.exe", "taskhost.exe"
    };

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Crea un DC per GDI+
    Gdiplus::Graphics graphics(memDC);

    // Disegna un overlay semi-trasparente
    Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
    graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

    // Numero di processi da "infettare"
    int processesToInject = std::min(static_cast<int>(processes.size()), 20);

    // Simula l'iniezione in ogni processo
    for (int i = 0; i < processesToInject; i++) {
        // Seleziona un processo casuale, preferendo quelli importanti
        std::string processName;
        DWORD pid;

        if (i < static_cast<int>(importantProcesses.size())) {
            // Cerca di trovare uno dei processi importanti
            bool found = false;
            for (const auto& proc : processes) {
                std::string procName = proc.szExeFile;
                if (procName == importantProcesses[i]) {
                    processName = procName;
                    pid = proc.th32ProcessID;
                    found = true;
                    break;
                }
            }

            if (!found) {
                // Se non trova il processo importante, prende uno casuale
                int index = rand() % processes.size();
                processName = processes[index].szExeFile;
                pid = processes[index].th32ProcessID;
            }
        } else {
            // Scegli un processo casuale
            int index = rand() % processes.size();
            processName = processes[index].szExeFile;
            pid = processes[index].th32ProcessID;
        }

        // Determina se il processo � critico
        bool isCritical = false;
        for (const auto& critProc : importantProcesses) {
            if (processName == critProc) {
                isCritical = true;
                break;
            }
        }

        // Crea informazioni sul processo simulato
        SystemProcess procInfo;
        procInfo.name = processName;
        procInfo.pid = pid;
        procInfo.parentPid = 0; // Non implementato
        procInfo.priority = GetRandomValue(1, 10);
        procInfo.user = "SYSTEM";
        procInfo.isCritical = isCritical;
        procInfo.cpuUsage = GetRandomValue(1, 30);
        procInfo.memoryUsage = GetRandomValue(1024, 100 * 1024);

        // Aggiungi moduli casuali
        procInfo.modules.push_back("kernel32.dll");
        procInfo.modules.push_back("user32.dll");
        procInfo.modules.push_back("ntdll.dll");
        procInfo.modules.push_back("nightmare_payload.dll");

        // Aggiungi alla lista dei processi simulati
        systemProcesses.push_back(procInfo);

        // Aggiorna le statistiche
        virusStatistics.processesInjected++;

        // Disegna la progress bar
        int progress = (i * 100) / processesToInject;

        Gdiplus::SolidBrush bgBrush(COLOR_HALF_TRANSPARENT_BLACK);
        graphics.FillRectangle(&bgBrush, screenWidth / 4, screenHeight / 2 - 60, screenWidth / 2, 120);

        Gdiplus::SolidBrush textBrush(COLOR_YELLOW);
        Gdiplus::Font font(L"Consolas", 12);
        Gdiplus::StringFormat format;
        format.SetAlignment(Gdiplus::StringAlignmentCenter);

        std::wstring statusText = L"Process Injection: " + std::to_wstring(i + 1) + L" of " + std::to_wstring(processesToInject);
        std::wstring procText = L"Injecting into: " + std::wstring(processName.begin(), processName.end()) + L" (PID: " + std::to_wstring(pid) + L")";
        std::wstring critText = isCritical ? L"CRITICAL SYSTEM PROCESS" : L"User process";

        Gdiplus::RectF statusRect(screenWidth / 4, screenHeight / 2 - 60, screenWidth / 2, 25);
        graphics.DrawString(statusText.c_str(), -1, &font, statusRect, &format, &textBrush);

        Gdiplus::RectF procRect(screenWidth / 4, screenHeight / 2 - 35, screenWidth / 2, 25);
        graphics.DrawString(procText.c_str(), -1, &font, procRect, &format, &textBrush);

        Gdiplus::RectF critRect(screenWidth / 4, screenHeight / 2 - 10, screenWidth / 2, 25);
        Gdiplus::SolidBrush critBrush(isCritical ? COLOR_RED : COLOR_GREEN);
        graphics.DrawString(critText.c_str(), -1, &font, critRect, &format, &critBrush);

        // Disegna la barra di progresso
        Gdiplus::RectF progressRect(screenWidth / 4, screenHeight / 2 + 20, screenWidth / 2, 20);
        Gdiplus::SolidBrush progressBgBrush(COLOR_GRAY);
        graphics.FillRectangle(&progressBgBrush, progressRect);

        Gdiplus::RectF progressFillRect(screenWidth / 4, screenHeight / 2 + 20, (screenWidth / 2) * progress / 100, 20);
        Gdiplus::SolidBrush progressFillBrush(COLOR_YELLOW);
        graphics.FillRectangle(&progressFillBrush, progressFillRect);

        // Mostra stato iniezione
        std::wstring injText = L"Processes infected: " + std::to_wstring(virusStatistics.processesInjected);
        Gdiplus::RectF injRect(screenWidth / 4, screenHeight / 2 + 45, screenWidth / 2, 25);
        graphics.DrawString(injText.c_str(), -1, &font, injRect, &format, &textBrush);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Breve pausa per visualizzare l'avanzamento
        Sleep(300);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);

    LogSuccess("ProcessInjection payload completed: %d processes infected", virusStatistics.processesInjected);
}

// Implementazioni di altre simulazioni di payload
void SimulateRegistryChanges() {
    LogMessage("Simulating registry changes (not actually modifying registry)...");
    Sleep(3000);
    virusStatistics.registryKeysModified = GetRandomValue(20, 100);
    LogSuccess("Registry simulation complete: %d keys virtually modified", virusStatistics.registryKeysModified);
}

void SimulatePasswordStealing() {
    LogMessage("Simulating password stealing (no actual passwords accessed)...");
    Sleep(3000);
    virusStatistics.passwordsStolen = GetRandomValue(10, 50);
    LogSuccess("Password simulation complete: %d passwords virtually stolen", virusStatistics.passwordsStolen);
}

void SimulateBrowserHistory() {
    LogMessage("Simulating browser history stealing (no actual history accessed)...");
    Sleep(3000);
    virusStatistics.browsersCleaned = GetRandomValue(3, 7);
    LogSuccess("Browser simulation complete: %d browsers virtually scanned", virusStatistics.browsersCleaned);
}

void SimulateSystemRecoveryDisabling() {
    LogMessage("Simulating system recovery disabling (not actually disabling anything)...");
    Sleep(3000);
    LogSuccess("System recovery simulation complete");
}

void SimulateAntivirusDisabling() {
    LogMessage("Simulating antivirus disabling (not actually disabling anything)...");
    Sleep(3000);
    LogSuccess("Antivirus disabling simulation complete");
}

void SimulateFirewallDisabling() {
    LogMessage("Simulating firewall disabling (not actually disabling anything)...");
    Sleep(3000);
    LogSuccess("Firewall disabling simulation complete");
}

void SimulateScreenCapture() {
    PerformScreenCapture();
}

void SimulateDataExfiltration() {
    LogMessage("Simulating data exfiltration (no actual data sent)...");
    Sleep(3000);
    virusStatistics.emailsSent = GetRandomValue(5, 15);
    LogSuccess("Data exfiltration simulation complete: %d virtual emails sent", virusStatistics.emailsSent);
}

void SimulateBootRecordModification() {
    LogMessage("Simulating boot record modification (not actually modifying anything)...");
    Sleep(3000);
    LogSuccess("Boot record modification simulation complete");
}

void SimulateUserAccountCreation() {
    LogMessage("Simulating backdoor user creation (not actually creating accounts)...");
    Sleep(3000);
    virusStatistics.accountsCompromised = GetRandomValue(2, 5);
    LogSuccess("User account simulation complete: %d virtual accounts created", virusStatistics.accountsCompromised);
}

void SimulateBitcoinMining() {
    LogMessage("Simulating cryptocurrency mining (no actual mining)...");
    Sleep(3000);
    LogSuccess("Bitcoin mining simulation complete");
}

void SimulateAudioRecording() {
    LogMessage("Simulating audio recording (not actually recording anything)...");
    Sleep(3000);
    LogSuccess("Audio recording simulation complete");
}

void SimulateWebcamCapture() {
    LogMessage("Simulating webcam capture (not actually accessing camera)...");
    Sleep(3000);
    LogSuccess("Webcam capture simulation complete");
}

void SimulateWifiHacking() {
    LogMessage("Simulating WiFi hacking (not actually hacking anything)...");
    Sleep(3000);
    LogSuccess("WiFi hacking simulation complete");
}

void SimulateUsbInfection() {
    LogMessage("Simulating USB device infection (not actually infecting anything)...");
    Sleep(3000);
    LogSuccess("USB infection simulation complete");
}

void SimulatePhishingAttack() {
    LogMessage("Simulating phishing attack preparation (not actually creating anything)...");
    Sleep(3000);
    LogSuccess("Phishing attack simulation complete");
}

void SimulateFileShredding() {
    LogMessage("Simulating file shredding (not actually deleting anything)...");
    Sleep(3000);
    LogSuccess("File shredding simulation complete");
}

void SimulateHardDriveFormatting() {
    LogMessage("Simulating hard drive formatting (not actually formatting anything)...");
    Sleep(3000);
    LogSuccess("Hard drive formatting simulation complete");
}

void SimulateSystemMeltdown() {
    LogMessage("Executing SystemMeltdown payload...");

    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Crea un DC per GDI+
    Gdiplus::Graphics graphics(memDC);

    // Effetto di degradazione progressiva
    for (int level = 0; level < 100; level++) {
        // Applica un effetto di dissolvenza
        Gdiplus::SolidBrush fadeBrush(Gdiplus::Color(level * 2, 0, 0, 0));
        graphics.FillRectangle(&fadeBrush, 0, 0, screenWidth, screenHeight);

        // Applica effetto di "scioglimento"
        for (int i = 0; i < 10 + level / 2; i++) {
            int x = rand() % screenWidth;
            int startY = rand() % screenHeight;
            int height = (rand() % 200) + 50 + level;
            int width = (rand() % 20) + 5;

            // Sfumatura trasparente che simula lo scioglimento
            for (int j = 0; j < height; j++) {
                int alpha = 255 - (j * 255 / height);
                Gdiplus::SolidBrush meltBrush(Gdiplus::Color(alpha, 0, 0, 0));
                graphics.FillRectangle(&meltBrush, x, startY + j, width, 1);
            }
        }

        // Aggiungi alcuni artefatti glitch casuali
        if (level > 30 && rand() % 100 < 30) {
            for (int i = 0; i < 5; i++) {
                int glitchX = rand() % screenWidth;
                int glitchY = rand() % screenHeight;
                int glitchW = (rand() % 300) + 50;
                int glitchH = (rand() % 50) + 10;

                // Copia una sezione dello schermo in una posizione casuale
                BitBlt(memDC, glitchX, glitchY, glitchW, glitchH, memDC,
                      (glitchX + rand() % 100 - 50) % screenWidth,
                      (glitchY + rand() % 100 - 50) % screenHeight,
                      SRCCOPY);
            }
        }

        // Aggiungi errori e avvisi casuali quando il sistema si "degrada"
        if (level > 50 && rand() % 100 < 20) {
            std::string errorMessages[] = {
                "SYSTEM ERROR: Memory corruption detected",
                "CRITICAL: Kernel integrity check failed",
                "WARNING: System drivers compromised",
                "ERROR: Boot sector corrupted",
                "FATAL: Execution halted, system unstable",
                "SECURITY BREACH: System files modified"
            };

            std::string errorMsg = errorMessages[rand() % 6];

            // Posizione casuale per il messaggio di errore
            int errX = rand() % (screenWidth - 400);
            int errY = rand() % (screenHeight - 100);

            DrawFakeErrorDialog(memDC, errX, errY, 400, 100, errorMsg);
        }

        // Mostra errore fatale quando si avvicina alla fine
        if (level > 90) {
            Gdiplus::Font errorFont(L"Arial", 24, Gdiplus::FontStyleBold);
            Gdiplus::SolidBrush errorBrush(COLOR_RED);
            Gdiplus::StringFormat errorFormat;
            errorFormat.SetAlignment(Gdiplus::StringAlignmentCenter);

            std::wstring errorText = L"FATAL SYSTEM ERROR - SYSTEM HALTED";
            Gdiplus::RectF errorRect(0, screenHeight / 2 - 50, screenWidth, 50);
            graphics.DrawString(errorText.c_str(), -1, &errorFont, errorRect, &errorFormat, &errorBrush);
        }

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Riproduci suoni di errore ad intervalli casuali
        if (rand() % 100 < 10) {
            GenerateSystemAlertSound();
        }

        // Pausa per visualizzare l'effetto
        Sleep(100);
    }

    // Alla fine, mostra una schermata blu della morte
    CreateFakeBlueScreen();

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);

    LogSuccess("SystemMeltdown payload completed");
}

void SimulateKernelPanic() {
    LogMessage("Simulating kernel panic (not actually causing any crashes)...");
    Sleep(3000);
    LogSuccess("Kernel panic simulation complete");
}

void SimulateRootkit() {
    LogMessage("Simulating rootkit installation (not actually installing anything)...");
    Sleep(3000);
    LogSuccess("Rootkit simulation complete");
}

void SimulateRansomwareAttack() {
    LogMessage("Executing RansomwareAttack payload...");

    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Crea un DC per GDI+
    Gdiplus::Graphics graphics(memDC);

    // Prima fase: mostra messaggio di cifratura
    {
        // Salva lo stato attuale dello schermo
        BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

        // Disegna un overlay semi-trasparente
        Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
        graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

        // Disegna il testo di avvertimento
        Gdiplus::SolidBrush textBrush(COLOR_RED);
        Gdiplus::Font titleFont(L"Impact", 36);
        Gdiplus::Font textFont(L"Arial", 18);
        Gdiplus::StringFormat format;
        format.SetAlignment(Gdiplus::StringAlignmentCenter);

        std::wstring warningText = L"WARNING: YOUR FILES ARE BEING ENCRYPTED";
        Gdiplus::RectF warningRect(0, screenHeight / 2 - 100, screenWidth, 50);
        graphics.DrawString(warningText.c_str(), -1, &titleFont, warningRect, &format, &textBrush);

        std::wstring infoText = L"All your personal files are being encrypted with military-grade encryption.";
        Gdiplus::RectF infoRect(0, screenHeight / 2 - 40, screenWidth, 30);
        graphics.DrawString(infoText.c_str(), -1, &textFont, infoRect, &format, &textBrush);

        // Barra di progresso
        Gdiplus::RectF progressRect(screenWidth / 4, screenHeight / 2, screenWidth / 2, 30);
        Gdiplus::SolidBrush progressBgBrush(COLOR_GRAY);
        graphics.FillRectangle(&progressBgBrush, progressRect);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Simula l'avanzamento della cifratura
        for (int i = 0; i <= 100; i++) {
            // Aggiorna la barra di progresso
            Gdiplus::RectF progressFillRect(screenWidth / 4, screenHeight / 2, (screenWidth / 2) * i / 100, 30);
            Gdiplus::SolidBrush progressFillBrush(COLOR_RED);
            graphics.FillRectangle(&progressFillBrush, progressFillRect);

            // Aggiorna il testo percentuale
            std::wstring percentText = std::to_wstring(i) + L"%";
            Gdiplus::RectF percentRect(0, screenHeight / 2, screenWidth, 30);

            // Prima cancella il testo precedente
            Gdiplus::SolidBrush clearBrush(COLOR_TRANSPARENT_BLACK);
            graphics.FillRectangle(&clearBrush, screenWidth / 4, screenHeight / 2, screenWidth / 2, 30);

            // Poi disegna la barra aggiornata
            graphics.FillRectangle(&progressBgBrush, progressRect);
            graphics.FillRectangle(&progressFillBrush, progressFillRect);

            // Infine disegna il testo percentuale
            Gdiplus::SolidBrush percentBrush(COLOR_WHITE);
            graphics.DrawString(percentText.c_str(), -1, &textFont, percentRect, &format, &percentBrush);

            // Copia l'immagine sullo schermo
            BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

            // Breve pausa per visualizzare l'avanzamento
            Sleep(50);
        }
    }

    // Seconda fase: mostra schermata di riscatto
    {
        // Copri l'intero schermo con rosso scuro
        Gdiplus::SolidBrush bgBrush(COLOR_DARK_RED);
        graphics.FillRectangle(&bgBrush, 0, 0, screenWidth, screenHeight);

        // Disegna il logo del ransomware
        Gdiplus::SolidBrush logoBrush(COLOR_WHITE);
        Gdiplus::Font logoFont(L"Impact", 72);
        Gdiplus::StringFormat logoFormat;
        logoFormat.SetAlignment(Gdiplus::StringAlignmentCenter);

        std::wstring logoText = L"NIGHTMARE LOCKER";
        Gdiplus::RectF logoRect(0, 50, screenWidth, 100);
        graphics.DrawString(logoText.c_str(), -1, &logoFont, logoRect, &logoFormat, &logoBrush);

        // Disegna un'icona di lucchetto
        int lockSize = 100;
        int lockX = (screenWidth - lockSize) / 2;
        int lockY = 170;

        Gdiplus::SolidBrush lockBrush(COLOR_WHITE);
        Gdiplus::Pen lockPen(COLOR_WHITE, 3);

        // Corpo del lucchetto
        graphics.FillRectangle(&lockBrush, lockX, lockY + lockSize / 3, lockSize, lockSize * 2 / 3);

        // Arco del lucchetto
        graphics.DrawArc(&lockPen, lockX + lockSize / 4, lockY, lockSize / 2, lockSize / 2, 180, 180);

        // Disegna il messaggio principale
        Gdiplus::SolidBrush textBrush(COLOR_WHITE);
        Gdiplus::Font titleFont(L"Arial", 24, Gdiplus::FontStyleBold);
        Gdiplus::Font textFont(L"Arial", 16);
        Gdiplus::StringFormat format;
        format.SetAlignment(Gdiplus::StringAlignmentCenter);

        int y = 300;
        int lineHeight = 30;

        std::wstring titleText = L"YOUR FILES HAVE BEEN ENCRYPTED!";
        Gdiplus::RectF titleRect(0, y, screenWidth, 40);
        graphics.DrawString(titleText.c_str(), -1, &titleFont, titleRect, &format, &textBrush);

        y += 60;

        std::vector<std::wstring> messageLines = {
            L"All your documents, photos, databases and other important files have been encrypted",
            L"with military-grade encryption and a unique key.",
            L"",
            L"To recover your files, you need to pay the decryption fee:",
            L"",
            L"PRICE: $500 USD in Bitcoin",
            L"",
            L"Send payment to Bitcoin address:",
            L"1Nightmare12345678912345678912345XYZ",
            L"",
            L"After payment, send proof to nightmare@example.com to receive the decryption key.",
            L"",
            L"WARNING: Do not attempt to decrypt your files with third-party software or",
            L"your files will be permanently damaged and recovery will be impossible!"
        };

        for (const auto& line : messageLines) {
            Gdiplus::RectF lineRect(0, y, screenWidth, lineHeight);
            graphics.DrawString(line.c_str(), -1, &textFont, lineRect, &format, &textBrush);
            y += lineHeight;
        }

        // Disegna il timer
        y += 40;

        std::wstring timerTitle = L"TIME REMAINING BEFORE PRICE INCREASE:";
        Gdiplus::RectF timerTitleRect(0, y, screenWidth, lineHeight);
        graphics.DrawString(timerTitle.c_str(), -1, &textFont, timerTitleRect, &format, &textBrush);

        y += lineHeight;

        std::wstring timerText = L"47:59:22";
        Gdiplus::Font timerFont(L"Consolas", 36, Gdiplus::FontStyleBold);
        Gdiplus::RectF timerRect(0, y, screenWidth, 50);
        graphics.DrawString(timerText.c_str(), -1, &timerFont, timerRect, &format, &textBrush);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Aspetta che l'utente prema un tasto
        Sleep(5000);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);

    LogSuccess("RansomwareAttack payload completed");
}

void SimulateBotnetConnection() {
    LogMessage("Simulating botnet connection (not actually connecting to anything)...");
    Sleep(3000);
    LogSuccess("Botnet connection simulation complete");
}

void SimulateZeroDay() {
    LogMessage("Simulating zero-day exploit (not actually exploiting anything)...");
    Sleep(3000);
    LogSuccess("Zero-day exploit simulation complete");
}

// Funzioni di effetti visivi

void DrawBloodDrips(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Numero di gocce basato sull'intensit�
    int numDrips = 3 + (intensity / 20);

    for (int i = 0; i < numDrips; i++) {
        int x = rand() % width;
        int length = (rand() % 200) + 50;
        int thickness = (rand() % 4) + 2;

        // Crea un brush per il sangue con trasparenza
        Gdiplus::SolidBrush bloodBrush(COLOR_RED);

        // Disegna la goccia principale
        graphics.FillRectangle(&bloodBrush, x, 0, thickness, length);

        // Disegna la goccia alla fine
        int dropWidth = thickness * 3;
        graphics.FillEllipse(&bloodBrush, x - dropWidth / 2 + thickness / 2, length - dropWidth / 2, dropWidth, dropWidth);
    }
}

void DrawStaticNoise(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Numero di pixel di rumore basato sull'intensit�
    int numPixels = (width * height * intensity) / 5000;

    // Colori per il rumore
    Gdiplus::Color colors[] = {
        COLOR_WHITE, COLOR_BLACK, COLOR_GRAY,
        COLOR_RED, COLOR_GREEN, COLOR_BLUE
    };

    // Dimensione dei pixel di rumore
    int pixelSize = 2 + (rand() % 3);

    for (int i = 0; i < numPixels; i++) {
        int x = rand() % width;
        int y = rand() % height;
        Gdiplus::Color pixelColor = colors[rand() % 6];

        Gdiplus::SolidBrush pixelBrush(pixelColor);
        graphics.FillRectangle(&pixelBrush, x, y, pixelSize, pixelSize);
    }
}

void DrawGlitchEffect(HDC hdc, int width, int height, int intensity) {
    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, width, height);
    SelectObject(memDC, memBitmap);

    // Copia lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

    // Numero di glitch basato sull'intensit�
    int numGlitches = 2 + (intensity / 20);

    for (int i = 0; i < numGlitches; i++) {
        // Seleziona una sezione orizzontale casuale
        int glitchY = rand() % height;
        int glitchHeight = (rand() % 50) + 10;
        int glitchOffset = (rand() % 100) - 50;

        // Sposta la sezione orizzontalmente
        BitBlt(hdc, glitchOffset, glitchY, width - abs(glitchOffset), glitchHeight,
               memDC, (glitchOffset > 0) ? 0 : -glitchOffset, glitchY, SRCCOPY);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
}

void DrawScanlines(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Distanza tra le scanlines basata sull'intensit�
    int lineSpacing = 8 - (intensity / 20);
    if (lineSpacing < 2) lineSpacing = 2;

    Gdiplus::Pen linePen(COLOR_TRANSPARENT_BLACK, 1);

    for (int y = 0; y < height; y += lineSpacing) {
        graphics.DrawLine(&linePen, 0, y, width, y);
    }
}

void DrawBinaryRain(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Numero di colonne di codice basato sull'intensit�
    int numColumns = 10 + (intensity / 10);

    for (int i = 0; i < numColumns; i++) {
        int x = rand() % width;
        int y = rand() % height;
        int columnHeight = rand() % 200 + 50;

        Gdiplus::Font font(L"Consolas", 12);
        Gdiplus::SolidBrush textBrush((rand() % 100 < 80) ? COLOR_GREEN : COLOR_WHITE);

        for (int j = 0; j < columnHeight; j += 20) {
            if (y + j < height) {
                wchar_t character = L'0' + (rand() % 2);
                graphics.DrawString(&character, 1, &font, Gdiplus::PointF(x, y + j), &textBrush);
            }
        }
    }
}

void DrawShatteredScreen(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Numero di linee di frattura basato sull'intensit�
    int numLines = 5 + (intensity / 10);

    Gdiplus::Pen crackPen(COLOR_WHITE, 2);

    // Punto centrale della frattura
    int centerX = width / 2 + (rand() % 200) - 100;
    int centerY = height / 2 + (rand() % 200) - 100;

    for (int i = 0; i < numLines; i++) {
        // Angolo casuale
        double angle = (rand() % 360) * M_PI / 180.0;
        int length = 100 + (rand() % 300);

        int endX = centerX + static_cast<int>(length * cos(angle));
        int endY = centerY + static_cast<int>(length * sin(angle));

        graphics.DrawLine(&crackPen, centerX, centerY, endX, endY);

        // Aggiungi alcune fratture secondarie
        if (rand() % 100 < 50) {
            double branchAngle = angle + ((rand() % 60) - 30) * M_PI / 180.0;
            int branchLength = length / 2;

            int branchX = centerX + static_cast<int>(branchLength * 0.7 * cos(angle));
            int branchY = centerY + static_cast<int>(branchLength * 0.7 * sin(angle));

            int branchEndX = branchX + static_cast<int>(branchLength * 0.5 * cos(branchAngle));
            int branchEndY = branchY + static_cast<int>(branchLength * 0.5 * sin(branchAngle));

            graphics.DrawLine(&crackPen, branchX, branchY, branchEndX, branchEndY);
        }
    }
}

void DrawSubtleDistortion(HDC hdc, int width, int height, int intensity) {
    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, width, height);
    SelectObject(memDC, memBitmap);

    // Copia lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

    // Numero di distorsioni basato sull'intensit�
    int numDistortions = 3 + (intensity / 20);

    for (int i = 0; i < numDistortions; i++) {
        // Seleziona un'area casuale
        int rectX = rand() % (width - 100);
        int rectY = rand() % (height - 100);
        int rectWidth = 50 + (rand() % 150);
        int rectHeight = 50 + (rand() % 150);

        // Applica una distorsione leggera (stiramento o compressione)
        int stretchMode = rand() % 2;
        if (stretchMode == 0) {
            // Distorsione orizzontale
            StretchBlt(hdc, rectX, rectY, rectWidth, rectHeight,
                      memDC, rectX, rectY, rectWidth * (0.8 + (rand() % 40) / 100.0), rectHeight,
                      SRCCOPY);
        } else {
            // Distorsione verticale
            StretchBlt(hdc, rectX, rectY, rectWidth, rectHeight,
                      memDC, rectX, rectY, rectWidth, rectHeight * (0.8 + (rand() % 40) / 100.0),
                      SRCCOPY);
        }
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
}

void DrawFlickeringEffect(HDC hdc, int width, int height, int intensity) {
    static bool flicker = false;
    flicker = !flicker;

    if (flicker && rand() % 100 < intensity) {
        // Intensit� dell'effetto basata sul parametro
        int alpha = 50 + (intensity / 2);
        if (alpha > 200) alpha = 200;

        Gdiplus::Graphics graphics(hdc);
        Gdiplus::SolidBrush flashBrush(Gdiplus::Color(alpha, 255, 255, 255));
        graphics.FillRectangle(&flashBrush, 0, 0, width, height);
    }
}

void DrawPsychedelicWaves(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    static float time = 0.0f;
    time += 0.1f;

    // Numero di onde basato sull'intensit�
    int numWaves = 3 + (intensity / 20);

    for (int i = 0; i < numWaves; i++) {
        // Colore casuale per l'onda
        Gdiplus::Color waveColor(
            100 + rand() % 155,
            rand() % 255,
            rand() % 255,
            rand() % 255
        );

        Gdiplus::Pen wavePen(waveColor, 2);

        // Parametri dell'onda
        float frequency = 0.01f + (rand() % 100) / 5000.0f;
        float amplitude = 20.0f + (intensity / 5.0f);
        float phase = time + i * 0.5f;

        // Disegna l'onda
        Gdiplus::Point* points = new Gdiplus::Point[width];
        for (int x = 0; x < width; x++) {
            int y = height / 2 + static_cast<int>(amplitude * sin(x * frequency + phase));
            points[x] = Gdiplus::Point(x, y);
        }

        graphics.DrawLines(&wavePen, points, width);

        delete[] points;
    }
}

void DrawRandomSymbols(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Simboli inquietanti da disegnare
    wchar_t symbols[] = L"!@#$%^&*()_+-=<>?/\\|{}[]~`";

    // Numero di simboli basato sull'intensit�
    int numSymbols = 10 + (intensity / 5);

    Gdiplus::SolidBrush symbolBrush(COLOR_RED);

    for (int i = 0; i < numSymbols; i++) {
        // Posizione e dimensione casuale
        int x = rand() % width;
        int y = rand() % height;
        int fontSize = 12 + (rand() % 24);

        // Simbolo casuale
        wchar_t symbol = symbols[rand() % wcslen(symbols)];

        // Font casuale
        std::wstring fontNames[] = {L"Arial", L"Times New Roman", L"Courier New", L"Impact", L"Consolas"};
        std::wstring fontName = fontNames[rand() % 5];
        Gdiplus::Font font(fontName.c_str(), static_cast<float>(fontSize));

        // Disegna il simbolo
        wchar_t symbolStr[2] = {symbol, L'\0'};
        graphics.DrawString(symbolStr, 1, &font, Gdiplus::PointF(x, y), &symbolBrush);
    }
}

void DrawTunnelEffect(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Numero di cerchi basato sull'intensit�
    int numCircles = 5 + (intensity / 10);

    // Centro del tunnel
    int centerX = width / 2;
    int centerY = height / 2;

    for (int i = 0; i < numCircles; i++) {
        // Dimensione del cerchio
        int size = (numCircles - i) * (width / numCircles / 2);

        // Colore del cerchio (alterna tra rosso e nero)
        Gdiplus::Color circleColor = (i % 2 == 0) ? COLOR_RED : COLOR_BLACK;
        Gdiplus::Pen circlePen(circleColor, 2);

        // Disegna il cerchio
        graphics.DrawEllipse(&circlePen, centerX - size / 2, centerY - size / 2, size, size);
    }
}

void DrawMeltingEffect(HDC hdc, int width, int height, int intensity) {
    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, width, height);
    SelectObject(memDC, memBitmap);

    // Copia lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

    // Numero di "colature" basato sull'intensit�
    int numMelts = 5 + (intensity / 10);

    for (int i = 0; i < numMelts; i++) {
        // Seleziona una colonna casuale
        int x = rand() % width;
        int meltHeight = 50 + (rand() % 200) * intensity / 100;

        // Applica l'effetto di scioglimento
        for (int y = 0; y < height - meltHeight; y++) {
            int sourceY = y;
            int destY = y + (y * meltHeight / height);

            if (destY < height) {
                // Copia un pixel dalla posizione originale a quella "sciolta"
                BitBlt(hdc, x, destY, 2, 1, memDC, x, sourceY, SRCCOPY);
            }
        }
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
}

void DrawSpinningHypnosis(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Centro dello schermo
    int centerX = width / 2;
    int centerY = height / 2;

    // Dimensione della spirale basata sull'intensit�
    int size = 100 + intensity * 2;

    static float rotation = 0.0f;
    rotation += 2.0f;

    // Disegna una spirale rotante
    Gdiplus::Pen spiralPen(COLOR_WHITE, 3);

    for (float angle = 0; angle < 10 * M_PI; angle += 0.1f) {
        float radius = angle * size / (10 * M_PI);
        float x1 = centerX + radius * cos(angle + rotation / 20.0f);
        float y1 = centerY + radius * sin(angle + rotation / 20.0f);
        float x2 = centerX + radius * cos(angle + 0.1f + rotation / 20.0f);
        float y2 = centerY + radius * sin(angle + 0.1f + rotation / 20.0f);

        graphics.DrawLine(&spiralPen, x1, y1, x2, y2);
    }
}

void DrawFallingCode(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Caratteri per il codice in stile Matrix
    wchar_t matrixChars[] = L"01";

    // Numero di colonne di codice basato sull'intensit�
    int numColumns = 10 + (intensity / 5);

    // Strutture statiche per tenere traccia delle colonne
    static std::vector<int> columnX;
    static std::vector<int> columnY;
    static std::vector<int> columnSpeed;

    // Inizializza le colonne se necessario
    if (columnX.empty() || static_cast<int>(columnX.size()) != numColumns) {
        columnX.resize(numColumns);
        columnY.resize(numColumns);
        columnSpeed.resize(numColumns);

        for (int i = 0; i < numColumns; i++) {
            columnX[i] = rand() % width;
            columnY[i] = -(rand() % 500);
            columnSpeed[i] = 5 + (rand() % 15);
        }
    }

    // Font per i caratteri
    Gdiplus::Font matrixFont(L"Consolas", 14);

    // Disegna e aggiorna ogni colonna
    for (int i = 0; i < numColumns; i++) {
        // Disegna la stringa di caratteri nella colonna
        int columnLength = 10 + (rand() % 20);

        for (int j = 0; j < columnLength; j++) {
            int y = columnY[i] + j * 20;

            if (y >= 0 && y < height) {
                // Seleziona un carattere casuale
                wchar_t character = matrixChars[rand() % wcslen(matrixChars)];
                wchar_t charStr[2] = {character, L'\0'};

                // Il primo carattere � pi� luminoso
                Gdiplus::SolidBrush charBrush((j == 0) ? COLOR_WHITE : COLOR_GREEN);
                graphics.DrawString(charStr, 1, &matrixFont, Gdiplus::PointF(columnX[i], y), &charBrush);
            }
        }

        // Aggiorna la posizione della colonna
        columnY[i] += columnSpeed[i];

        // Se la colonna � uscita dallo schermo, resettala
        if (columnY[i] - 20 * columnLength > height) {
            columnY[i] = -(rand() % 500);
            columnX[i] = rand() % width;
            columnSpeed[i] = 5 + (rand() % 15);
        }
    }
}

void DrawSystemError(HDC hdc, int width, int height, int intensity) {
    Gdiplus::Graphics graphics(hdc);

    // Numero di finestre di errore basato sull'intensit�
    int numErrors = 1 + (intensity / 25);

    // Messaggi di errore inquietanti
    std::vector<std::string> errorMessages = {
        "SYSTEM FAILURE: Critical process terminated",
        "SECURITY ALERT: System compromised",
        "WARNING: Disk corruption detected",
        "FATAL ERROR: System files corrupted",
        "ERROR: Boot sector infected",
        "CRITICAL: Memory corruption detected",
        "WARNING: Firmware integrity check failed"
    };

    for (int i = 0; i < numErrors; i++) {
        // Posizione casuale per la finestra di errore
        int errX = rand() % (width - 350);
        int errY = rand() % (height - 150);

        // Seleziona un messaggio casuale
        std::string errorMsg = errorMessages[rand() % errorMessages.size()];

        // Disegna la finestra di errore
        DrawFakeErrorDialog(hdc, errX, errY, 350, 150, errorMsg);
    }
}

void DrawFlashingText(HDC hdc, int width, int height, int intensity) {
    static bool showText = false;
    showText = !showText;

    if (showText && rand() % 100 < intensity) {
        Gdiplus::Graphics graphics(hdc);

        // Messaggi inquietanti
        std::vector<std::wstring> messages = {
            L"SYSTEM COMPROMISED",
            L"ALL YOUR FILES ARE GONE",
            L"NO ESCAPE",
            L"WATCHING YOU",
            L"DELETING SYSTEM",
            L"INFECTED",
            L"NO RECOVERY POSSIBLE"
        };

        // Seleziona un messaggio casuale
        std::wstring message = messages[rand() % messages.size()];

        // Font grande e rosso
        Gdiplus::Font warningFont(L"Impact", 36);
        Gdiplus::SolidBrush warningBrush(COLOR_RED);

        // Posizione casuale
        int textX = width / 4 + (rand() % (width / 2));
        int textY = height / 4 + (rand() % (height / 2));

        // Disegna il messaggio
        graphics.DrawString(message.c_str(), -1, &warningFont, Gdiplus::PointF(textX, textY), &warningBrush);
    }
}

void DrawInvertedColors(HDC hdc, int width, int height, int intensity) {
    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, width, height);
    SelectObject(memDC, memBitmap);

    // Copia lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, width, height, hdc, 0, 0, SRCCOPY);

    // Inverti i colori solo se l'intensit� � sufficientemente alta
    if (rand() % 100 < intensity / 2) {
        BitBlt(hdc, 0, 0, width, height, memDC, 0, 0, NOTSRCCOPY);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
}

// Implementazioni delle funzioni per generare suoni

void GenerateCreepySound(int type) {
    switch (type % 10) {
        case 0: GenerateExplosionSound(); break;
        case 1: GenerateSystemAlertSound(); break;
        case 2: GenerateGlitchSound(); break;
        case 3: GenerateErrorBeepSequence(); break;
        case 4: GenerateHighPitchedWhine(); break;
        case 5: GenerateHeartbeatSound(); break;
        case 6: GenerateReverseSound(); break;
        case 7: GenerateStaticNoise(); break;
        case 8: GenerateWhisperingVoices(); break;
        case 9: GenerateCreepyMusic(); break;
    }
}

void GenerateExplosionSound() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 1; // 1 secondo
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;
        float amplitude = 32767.0f * exp(-t * 4);

        // Mix di rumore bianco e onde sinusoidali a bassa frequenza
        float noise = (rand() % 32767) * 2.0f - 32767.0f;
        float bass = 32767.0f * sin(2 * M_PI * 40 * t) * exp(-t * 8);

        waveform[i] = (short)(amplitude * (0.7f * noise + 0.3f * bass) / 1.0f);
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateSystemAlertSound() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 1; // 1 secondo
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Sequenza di beep di sistema
    float frequencies[] = {800, 600, 400};
    int numBeeps = 3;

    for (int beep = 0; beep < numBeeps; beep++) {
        float frequency = frequencies[beep];
        int start = (beep * waveform.size()) / numBeeps;
        int end = ((beep + 1) * waveform.size()) / numBeeps;

        for (int i = start; i < end; i++) {
            float t = (float)(i - start) / SAMPLE_RATE;
            float envelope = 1.0f;
            if (t < 0.01f) envelope = t / 0.01f;
            if (t > (end - start) / SAMPLE_RATE - 0.01f) envelope = ((end - start) / SAMPLE_RATE - t) / 0.01f;

            waveform[i] = (short)(32767.0f * sin(2 * M_PI * frequency * t) * envelope);
        }
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateGlitchSound() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 1; // 1 secondo
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;

        // Crea un suono "glitch" usando repentini cambi di frequenza
        float glitchRate = 20.0f + 100.0f * sin(2 * M_PI * 3 * t);
        float frequency = 400.0f + 200.0f * sin(2 * M_PI * glitchRate * t);

        // Aggiungi rumore digitale
        if (rand() % 10 == 0) {
            waveform[i] = (short)(rand() % 32767);
        } else {
            waveform[i] = (short)(32767.0f * sin(2 * M_PI * frequency * t));
        }

        // Ogni tanto, inserisci un silenzio improvviso
        if (rand() % 100 == 0) {
            int silenceLength = rand() % 500;
            for (int j = 0; j < silenceLength && i + j < waveform.size(); j++) {
                waveform[i + j] = 0;
            }
            i += silenceLength;
        }
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateErrorBeepSequence() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 2; // 2 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Sequenza di beep di errore
    int numBeeps = 5;
    int samplesPerBeep = waveform.size() / numBeeps;

    for (int beep = 0; beep < numBeeps; beep++) {
        float frequency = (beep % 2 == 0) ? 800.0f : 600.0f;
        int start = beep * samplesPerBeep;
        int end = (beep + 1) * samplesPerBeep;

        for (int i = start; i < end; i++) {
            float t = (float)(i - start) / SAMPLE_RATE;
            float beepDuration = (samplesPerBeep / 2) / (float)SAMPLE_RATE;

            if (t < beepDuration) {
                waveform[i] = (short)(32767.0f * sin(2 * M_PI * frequency * t));
            } else {
                waveform[i] = 0; // Silenzio tra i beep
            }
        }
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateHighPitchedWhine() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 3; // 3 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;

        // Frequenza che varia lentamente
        float frequency = 2000.0f + 1000.0f * sin(2 * M_PI * 0.5f * t);

        // Ampiezza che cresce e decresce
        float amplitude = 32767.0f * (0.3f + 0.7f * sin(2 * M_PI * 0.2f * t));

        waveform[i] = (short)(amplitude * sin(2 * M_PI * frequency * t));
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateHeartbeatSound() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 3; // 3 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Parametri del battito cardiaco
    float beatsPerSecond = 1.5f; // Battiti al secondo (90 BPM)

    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;

        // Determina la posizione nel ciclo del battito
        float beatTime = fmod(t * beatsPerSecond, 1.0f);

        // Genera i due suoni del battito (lub-dub)
        if (beatTime < 0.1f) {
            float beatPhase = beatTime / 0.1f;
            float amplitude = 32767.0f * sin(beatPhase * M_PI) * exp(-beatPhase * 5);
            waveform[i] = (short)(amplitude * sin(2 * M_PI * 100 * t));
        } else if (beatTime < 0.2f) {
            float beatPhase = (beatTime - 0.1f) / 0.1f;
            float amplitude = 24576.0f * sin(beatPhase * M_PI) * exp(-beatPhase * 5);
            waveform[i] = (short)(amplitude * sin(2 * M_PI * 80 * t));
        } else {
            waveform[i] = 0;
        }
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateReverseSound() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 2; // 2 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Genera un suono sinusoidale di base con frequenza decrescente
    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;
        float frequency = 1000.0f - 800.0f * t / DURATION;
        waveform[i] = (short)(32767.0f * sin(2 * M_PI * frequency * t));
    }

    // Inverti il suono
    std::reverse(waveform.begin(), waveform.end());

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateStaticNoise() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 2; // 2 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Genera rumore bianco
    for (size_t i = 0; i < waveform.size(); i++) {
        waveform[i] = (short)((rand() % 65536) - 32768);
    }

    // Applica un'inviluppo per evitare click all'inizio e alla fine
    for (size_t i = 0; i < SAMPLE_RATE / 10; i++) {
        float fadeIn = (float)i / (SAMPLE_RATE / 10);
        waveform[i] = (short)(waveform[i] * fadeIn);

        float fadeOut = (float)(SAMPLE_RATE * DURATION - i - 1) / (SAMPLE_RATE / 10);
        waveform[waveform.size() - i - 1] = (short)(waveform[waveform.size() - i - 1] * fadeOut);
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateWhisperingVoices() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 3; // 3 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Genera un mix di frequenze filtrate per simulare voci sussurranti
    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;

        // Mix di diverse frequenze
        float signal = 0.0f;
        for (int j = 0; j < 5; j++) {
            float freq = 200.0f + j * 100.0f + 50.0f * sin(2 * M_PI * (0.1f + j * 0.05f) * t);
            signal += 0.2f * sin(2 * M_PI * freq * t);
        }

        // Modula con rumore per un effetto "sussurrato"
        float noise = (float)(rand() % 1000) / 1000.0f;
        float envelope = 0.3f + 0.7f * sin(2 * M_PI * 0.5f * t) * sin(2 * M_PI * 0.2f * t);

        waveform[i] = (short)(16384.0f * signal * noise * envelope);
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

void GenerateCreepyMusic() {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 5; // 5 secondi
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    // Note di una scala minore inquietante
    float notes[] = {
        261.63f,  // C
        277.18f,  // C#
        311.13f,  // D#
        349.23f,  // F
        369.99f,  // F#
        415.3f,   // G#
        466.16f   // A#
    };

    // Genera una melodia inquietante
    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;

        // Cambia nota ogni mezzo secondo
        int noteIndex = (int)(t * 2) % 7;
        float frequency = notes[noteIndex];

        // Aggiungi alcune armoniche
        float signal = 0.5f * sin(2 * M_PI * frequency * t) +
                      0.25f * sin(2 * M_PI * frequency * 2 * t) +
                      0.125f * sin(2 * M_PI * frequency * 3 * t);

        // Applica un tremolo
        float tremolo = 0.8f + 0.2f * sin(2 * M_PI * 8 * t);

        // Applica un'inviluppo ADSR semplice
        float envelope = 1.0f;
        float noteTime = fmod(t, 0.5f);
        if (noteTime < 0.05f) {
            envelope = noteTime / 0.05f; // Attack
        } else if (noteTime > 0.4f) {
            envelope = (0.5f - noteTime) / 0.1f; // Release
        }

        waveform[i] = (short)(16384.0f * signal * tremolo * envelope);
    }

    WAVEFORMATEX wfx = { 0 };
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = SAMPLE_RATE;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample) / 8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;

    HWAVEOUT hWaveOut;
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);

    WAVEHDR whdr = { 0 };
    whdr.lpData = (LPSTR)waveform.data();
    whdr.dwBufferLength = waveform.size() * sizeof(short);

    waveOutPrepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &whdr, sizeof(WAVEHDR));

    Sleep(DURATION * 1000);

    waveOutUnprepareHeader(hWaveOut, &whdr, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}

// Funzioni di supporto

void DrawFakeErrorDialog(HDC hdc, int x, int y, int width, int height, const std::string& errorMessage) {
    // Disegna il bordo della finestra
    HBRUSH hBrushTitleBar = CreateSolidBrush(RGB(200, 0, 0));
    HBRUSH hBrushWindow = CreateSolidBrush(RGB(240, 240, 240));
    HPEN hPenBorder = CreatePen(PS_SOLID, 1, RGB(160, 160, 160));

    SelectObject(hdc, hPenBorder);
    SelectObject(hdc, hBrushWindow);

    // Corpo della finestra
    Rectangle(hdc, x, y, x + width, y + height);

    // Barra del titolo
    SelectObject(hdc, hBrushTitleBar);
    Rectangle(hdc, x, y, x + width, y + 25);

    // Testo della barra del titolo
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(255, 255, 255));

    std::string title = "System Error";
    TextOut(hdc, x + 5, y + 5, title.c_str(), title.length());

    // Pulsante di chiusura
    SelectObject(hdc, hBrushWindow);
    Rectangle(hdc, x + width - 25, y + 5, x + width - 5, y + 20);

    // 'X' sul pulsante di chiusura
    SetTextColor(hdc, RGB(0, 0, 0));
    TextOut(hdc, x + width - 18, y + 5, "X", 1);

    // Icona di errore
    int iconSize = 32;
    int iconX = x + 20;
    int iconY = y + 40;

    // Cerchio rosso con '!' bianco come icona di errore
    HBRUSH hBrushIcon = CreateSolidBrush(RGB(255, 0, 0));
    SelectObject(hdc, hBrushIcon);
    Ellipse(hdc, iconX, iconY, iconX + iconSize, iconY + iconSize);

    SetTextColor(hdc, RGB(255, 255, 255));
    TextOut(hdc, iconX + 14, iconY + 8, "!", 1);

    // Testo del messaggio di errore
    SetTextColor(hdc, RGB(0, 0, 0));
    RECT textRect = {x + iconSize + 30, y + 40, x + width - 10, y + height - 40};
    DrawText(hdc, errorMessage.c_str(), errorMessage.length(), &textRect, DT_WORDBREAK);

    // Pulsante OK
    Rectangle(hdc, x + width - 90, y + height - 35, x + width - 10, y + height - 10);
    TextOut(hdc, x + width - 60, y + height - 28, "OK", 2);

    // Pulizia
    DeleteObject(hBrushTitleBar);
    DeleteObject(hBrushWindow);
    DeleteObject(hBrushIcon);
    DeleteObject(hPenBorder);
}

void DrawProgressBar(HDC hdc, int x, int y, int width, int height, int progress, const std::string& text) {
    // Sfondo della barra
    HBRUSH hBrushBg = CreateSolidBrush(RGB(240, 240, 240));
    HBRUSH hBrushFill = CreateSolidBrush(RGB(0, 128, 0));
    HPEN hPenBorder = CreatePen(PS_SOLID, 1, RGB(160, 160, 160));

    SelectObject(hdc, hPenBorder);
    SelectObject(hdc, hBrushBg);

    // Disegna il bordo e lo sfondo
    Rectangle(hdc, x, y, x + width, y + height);

    // Calcola la larghezza del riempimento
    int fillWidth = (width * progress) / 100;

    // Disegna il riempimento
    SelectObject(hdc, hBrushFill);
    Rectangle(hdc, x, y, x + fillWidth, y + height);

    // Disegna il testo
    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, RGB(0, 0, 0));

    RECT textRect = {x, y, x + width, y + height};
    DrawText(hdc, text.c_str(), text.length(), &textRect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

    // Pulizia
    DeleteObject(hBrushBg);
    DeleteObject(hBrushFill);
    DeleteObject(hPenBorder);
}

void PerformScreenCapture() {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Crea un DC compatibile per lo screenshot
    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HBITMAP hbmScreen = CreateCompatibleBitmap(hdcScreen, screenWidth, screenHeight);
    SelectObject(hdcMem, hbmScreen);

    // Cattura lo schermo
    BitBlt(hdcMem, 0, 0, screenWidth, screenHeight, hdcScreen, 0, 0, SRCCOPY);

    // Salva lo screenshot in un file BMP nella cartella temporanea (simulazione)
    std::string screenshotPath = tempPath + "screenshot_" + std::to_string(time(nullptr)) + ".bmp";

    // In realt� lo screenshot non viene salvato, solo simulato
    LogMessage("Screenshot captured (simulated): %s", screenshotPath.c_str());
    virusStatistics.screenshotsCaptered++;

    // Pulizia
    DeleteObject(hbmScreen);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}

std::string GenerateRandomFileName() {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    std::string result;
    result.resize(12);

    for (int i = 0; i < 12; i++) {
        result[i] = charset[rand() % (sizeof(charset) - 1)];
    }

    return result;
}

std::string GenerateRandomIP() {
    std::string ip;
    ip = std::to_string(rand() % 256) + "." +
         std::to_string(rand() % 256) + "." +
         std::to_string(rand() % 256) + "." +
         std::to_string(rand() % 256);
    return ip;
}

std::string GenerateRandomMAC() {
    char mac[18];
    snprintf(mac, sizeof(mac), "%02X:%02X:%02X:%02X:%02X:%02X",
            rand() % 256, rand() % 256, rand() % 256,
            rand() % 256, rand() % 256, rand() % 256);
    return std::string(mac);
}

std::string GenerateRandomHash() {
    const char hexchars[] = "0123456789abcdef";
    std::string hash;

    for (int i = 0; i < 32; i++) {
        hash += hexchars[rand() % 16];
    }

    return hash;
}

std::string GenerateRandomPassword(int length) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
    std::string result;
    result.resize(length);

    for (int i = 0; i < length; i++) {
        result[i] = charset[rand() % (sizeof(charset) - 1)];
    }

    return result;
}

std::string GenerateRandomEncryptionExt() {
    std::vector<std::string> extensions = {
        ".locked", ".encrypted", ".cry", ".corona", ".darkness",
        ".nightmare", ".fear", ".terror", ".horror", ".dead"
    };

    return extensions[rand() % extensions.size()];
}

void ShowMessageBoxInfo(const std::string& title, const std::string& message) {
    MessageBox(NULL, message.c_str(), title.c_str(), MB_ICONINFORMATION | MB_OK);
}

void ShowMessageBoxError(const std::string& title, const std::string& message) {
    MessageBox(NULL, message.c_str(), title.c_str(), MB_ICONERROR | MB_OK);
}

void ShowMessageBoxWarning(const std::string& title, const std::string& message) {
    MessageBox(NULL, message.c_str(), title.c_str(), MB_ICONWARNING | MB_OK);
}

void SimulateDelayWithProgress(int milliseconds, const std::string& activity) {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Disegna un overlay semi-trasparente
    Gdiplus::Graphics graphics(memDC);
    Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
    graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

    // Calcola il numero di passi
    int numSteps = 100;
    int stepDelay = milliseconds / numSteps;

    for (int i = 0; i <= numSteps; i++) {
        // Disegna la progress bar
        std::string progressText = activity + " - " + std::to_string(i) + "%";
        DrawProgressBar(memDC, screenWidth / 4, screenHeight / 2, screenWidth / 2, 30, i, progressText);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Breve pausa
        Sleep(stepDelay);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);
}

void IncrementProgress(int amount) {
    currentProgress += amount;
    if (currentProgress > PROGRESS_MAX) {
        currentProgress = PROGRESS_MAX;
    }

    UpdateProgressBar(currentProgress);
}

int GetRandomValue(int min, int max) {
    return min + (rand() % (max - min + 1));
}

float GetRandomFloat(float min, float max) {
    return min + (float)rand() / ((float)RAND_MAX / (max - min));
}

void PrintFakeCommandOutput(const std::string& command, int lineCount) {
    LogMessage("Fake command: %s", command.c_str());

    // Genera linee di output casuali
    std::vector<std::string> outputs = {
        "Operation completed successfully.",
        "Processing request...",
        "Analyzing system files...",
        "Found 487 vulnerabilities.",
        "Exploiting security flaw CVE-2023-11111...",
        "Access granted to admin subsystem.",
        "Bypassing Windows Defender...",
        "Bypassing User Account Control...",
        "Creating backdoor entry point...",
        "Installing rootkit components...",
        "Hiding from system scanners...",
        "Disabling security services...",
        "Disabling event logging...",
        "Establishing encrypted channel...",
        "Downloading additional modules...",
        "Patching memory functions...",
        "Hijacking system calls..."
    };

    for (int i = 0; i < lineCount; i++) {
        std::string output = outputs[rand() % outputs.size()];
        LogMessage("Output: %s", output.c_str());
        Sleep(GetRandomValue(100, 500));
    }
}

void DisplayCountdown(int seconds, const std::string& message) {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Disegna un overlay semi-trasparente
    Gdiplus::Graphics graphics(memDC);
    Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
    graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

    // Font per il testo
    Gdiplus::Font font(L"Arial", 24, Gdiplus::FontStyleBold);
    Gdiplus::StringFormat format;
    format.SetAlignment(Gdiplus::StringAlignmentCenter);

    for (int i = seconds; i >= 0; i--) {
        // Cancella l'area del testo
        Gdiplus::SolidBrush clearBrush(COLOR_TRANSPARENT_BLACK);
        graphics.FillRectangle(&clearBrush, screenWidth / 4, screenHeight / 2 - 50, screenWidth / 2, 100);

        // Disegna il messaggio
        std::wstring wMessage(message.begin(), message.end());
        std::wstring countdownText = wMessage + L": " + std::to_wstring(i);

        Gdiplus::RectF textRect(screenWidth / 4, screenHeight / 2 - 50, screenWidth / 2, 100);
        Gdiplus::SolidBrush textBrush(COLOR_RED);
        graphics.DrawString(countdownText.c_str(), -1, &font, textRect, &format, &textBrush);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Pausa di un secondo
        Sleep(1000);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);
}

void SimulateTypingText(const std::string& text, int delayBetweenChars) {
    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Disegna la progress bar sulla finestra
    HDC hdc = GetDC(NULL);

    // Crea un DC compatibile per il double buffering
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBitmap = CreateCompatibleBitmap(hdc, screenWidth, screenHeight);
    SelectObject(memDC, memBitmap);

    // Salva lo stato attuale dello schermo
    BitBlt(memDC, 0, 0, screenWidth, screenHeight, hdc, 0, 0, SRCCOPY);

    // Crea un DC per GDI+
    Gdiplus::Graphics graphics(memDC);

    // Disegna un overlay semi-trasparente
    Gdiplus::SolidBrush overlayBrush(COLOR_TRANSPARENT_BLACK);
    graphics.FillRectangle(&overlayBrush, 0, 0, screenWidth, screenHeight);

    // Simula la battitura carattere per carattere
    Gdiplus::Font font(L"Consolas", 16);
    Gdiplus::SolidBrush textBrush(COLOR_GREEN);

    int x = 50;
    int y = 50;

    for (size_t i = 0; i <= text.length(); i++) {
        // Cancella la riga precedente
        Gdiplus::SolidBrush clearBrush(COLOR_BLACK);
        graphics.FillRectangle(&clearBrush, x, y, screenWidth - 100, 25);

        // Disegna il testo fino al carattere attuale
        std::wstring wText(text.begin(), text.begin() + i);
        graphics.DrawString(wText.c_str(), -1, &font, Gdiplus::PointF(x, y), &textBrush);

        // Copia l'immagine sullo schermo
        BitBlt(hdc, 0, 0, screenWidth, screenHeight, memDC, 0, 0, SRCCOPY);

        // Breve pausa per simulare la battitura
        Sleep(delayBetweenChars);
    }

    // Pulizia
    DeleteObject(memBitmap);
    DeleteDC(memDC);
    ReleaseDC(NULL, hdc);
}

void WaitForKeypress() {
    // Aspetta che l'utente prema un tasto qualsiasi
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    FlushConsoleInputBuffer(hStdin);

    DWORD mode;
    GetConsoleMode(hStdin, &mode);

    // Disabilita l'eco del carattere e l'input in linea
    SetConsoleMode(hStdin, 0);

    // Aspetta che l'utente prema un tasto
    INPUT_RECORD record;
    DWORD numRead;

    do {
        ReadConsoleInput(hStdin, &record, 1, &numRead);
    } while (record.EventType != KEY_EVENT || !record.Event.KeyEvent.bKeyDown);

    // Ripristina la modalit� precedente
    SetConsoleMode(hStdin, mode);
}

void ShowFinalStats() {
    LogMessage("=== FINAL VIRUS STATISTICS ===");
    LogMessage("Files encrypted: %d", virusStatistics.filesEncrypted);
    LogMessage("Processes injected: %d", virusStatistics.processesInjected);
    LogMessage("Registry keys modified: %d", virusStatistics.registryKeysModified);
    LogMessage("Accounts compromised: %d", virusStatistics.accountsCompromised);
    LogMessage("Services disabled: %d", virusStatistics.servicesDisabled);
    LogMessage("Networks compromised: %d", virusStatistics.networksCompromised);
    LogMessage("Screenshots captured: %d", virusStatistics.screenshotsCaptered);
    LogMessage("Passwords stolen: %d", virusStatistics.passwordsStolen);
    LogMessage("Browsers cleaned: %d", virusStatistics.browsersCleaned);
    LogMessage("Emails sent: %d", virusStatistics.emailsSent);
    LogMessage("Total damage cost: $%d", virusStatistics.totalDamageCost);
    LogMessage("System reboot count: %d", virusStatistics.systemRebootCount);
    LogMessage("==============================");
}

DWORD WINAPI VisualEffectsThread(LPVOID lpParam) {
    LogMessage("VisualEffects thread started");

    while (!shouldExit) {
        if (!revealMode) {
            // Esegui effetti visivi
            DrawVisualEffects();
        }

        // Pausa breve
        Sleep(50);
    }

    LogMessage("VisualEffects thread terminated");
    return 0;
}

DWORD WINAPI SoundEffectsThread(LPVOID lpParam) {
    LogMessage("SoundEffects thread started");

    while (!shouldExit) {
        if (!revealMode) {
            // Esegui effetti sonori a intervalli casuali
            if (rand() % 100 < 20) {
                GenerateCreepySound(rand() % 10);
            }
        }

        // Pausa tra i suoni
        Sleep(SOUND_INTERVAL + rand() % 5000);
    }

    LogMessage("SoundEffects thread terminated");
    return 0;
}

DWORD WINAPI PayloadExecutionThread(LPVOID lpParam) {
    LogMessage("PayloadExecution thread started");

    // Esegui i payload in sequenza durante le fasi
    while (!shouldExit && !revealMode) {
        ExecuteNextStage();

        // Pausa prima del prossimo payload
        Sleep(1000);
    }

    LogMessage("PayloadExecution thread terminated");
    return 0;
}

DWORD WINAPI SimulationTimerThread(LPVOID lpParam) {
    LogMessage("SimulationTimer thread started");

    // Attendi per la durata della simulazione
    Sleep(SIMULATION_TIMER);

    // Dopo il timer, rivela che � una simulazione sicura
    RevealPrank();

    LogMessage("SimulationTimer thread terminated");
    return 0;
}

// Funzione per eseguire il prossimo stadio
void ExecuteNextStage() {
    switch (currentStage) {
        case STAGE_INITIALIZATION:
            SetDestructionStage(STAGE_SYSTEM_ANALYSIS);
            break;

        case STAGE_SYSTEM_ANALYSIS:
            SimulateNetworkScan();
            SetDestructionStage(STAGE_FILE_ENUMERATION);
            break;

        case STAGE_FILE_ENUMERATION:
            SimulateFileEncryption();
            SetDestructionStage(STAGE_NETWORK_SCANNING);
            break;

        case STAGE_NETWORK_SCANNING:
            SimulateNetworkScan();
            SetDestructionStage(STAGE_PROCESS_INJECTION);
            break;

        case STAGE_PROCESS_INJECTION:
            SimulateProcessInjection();
            SetDestructionStage(STAGE_PERSISTENCE_CREATION);
            break;

        case STAGE_PERSISTENCE_CREATION:
            SimulateRootkit();
            SetDestructionStage(STAGE_REGISTRY_MANIPULATION);
            break;

        case STAGE_REGISTRY_MANIPULATION:
            SimulateRegistryChanges();
            SetDestructionStage(STAGE_SECURITY_BYPASS);
            break;

        case STAGE_SECURITY_BYPASS:
            SimulateAntivirusDisabling();
            SimulateFirewallDisabling();
            SetDestructionStage(STAGE_FILE_ENCRYPTION);
            break;

        case STAGE_FILE_ENCRYPTION:
            SimulateFileEncryption();
            SetDestructionStage(STAGE_RANSOM_PREPARATION);
            break;

        case STAGE_RANSOM_PREPARATION:
            SimulateRansomwareAttack();
            SetDestructionStage(STAGE_BOOT_MODIFICATION);
            break;

        case STAGE_BOOT_MODIFICATION:
            SimulateBootRecordModification();
            SetDestructionStage(STAGE_DATA_EXFILTRATION);
            break;

        case STAGE_DATA_EXFILTRATION:
            SimulateDataExfiltration();
            SetDestructionStage(STAGE_BROWSER_HIJACKING);
            break;

        case STAGE_BROWSER_HIJACKING:
            SimulateBrowserHistory();
            SetDestructionStage(STAGE_LATERAL_MOVEMENT);
            break;

        case STAGE_LATERAL_MOVEMENT:
            SimulateWifiHacking();
            SetDestructionStage(STAGE_PRIVILEGE_ESCALATION);
            break;

        case STAGE_PRIVILEGE_ESCALATION:
            SimulateUserAccountCreation();
            SetDestructionStage(STAGE_RECOVERY_DISABLING);
            break;

        case STAGE_RECOVERY_DISABLING:
            SimulateSystemRecoveryDisabling();
            SetDestructionStage(STAGE_FINAL_DESTRUCTION);
            break;

        case STAGE_FINAL_DESTRUCTION:
            SimulateSystemMeltdown();
            SetDestructionStage(STAGE_CLEANUP);
            break;

        case STAGE_CLEANUP:
            // Questa fase si verifica solo se il timer non � scaduto
            // Avvia la fase finale di distruzione
            CreateFakeBlueScreen();
            break;

        case STAGE_REVEAL:
            // Niente da fare qui, questo � gestito dal timer
            break;
    }
}

// Disegna tutti gli effetti visivi
void DrawVisualEffects() {
    std::lock_guard<std::mutex> lock(screenMutex);

    // Ottiene le dimensioni dello schermo
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Ottiene il DC dello schermo
    HDC hdc = GetDC(NULL);

    // Seleziona casualmente alcuni effetti visivi da mostrare
    int numEffects = 1 + (destructionLevel / 3);
    if (numEffects > 5) numEffects = 5;

    for (int i = 0; i < numEffects; i++) {
        // Seleziona un effetto casuale
        int effectIndex = rand() % visualEffects.size();

        // Intensit� basata sul livello di distruzione
        int intensity = 20 + destructionLevel * 8;
        if (intensity > 100) intensity = 100;

        // Esegue l'effetto
        visualEffects[effectIndex].drawFunction(hdc, screenWidth, screenHeight, intensity);
    }

    // Rilascia il DC
    ReleaseDC(NULL, hdc);
}

// Funzione per rivelare che si tratta di uno scherzo
void RevealPrank() {
    // Imposta la modalit� di rivelazione
    revealMode = true;
    LogMessage("Entering reveal mode - stopping all malicious simulations");

    // Nascondi la schermata di riscatto se attiva
    if (hWndRansom != NULL) {
        HideRansomwareScreen();
    }

    // Mostra un messaggio di rivelazione
    HDC hdc = GetDC(NULL);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Pulisci lo schermo
    RECT rect = {0, 0, screenWidth, screenHeight};
    HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(hdc, &rect, hBrush);
    DeleteObject(hBrush);

    // Mostra un conto alla rovescia prima della rivelazione
    Gdiplus::Graphics graphics(hdc);
    Gdiplus::Font countdownFont(L"Impact", 72);
    Gdiplus::SolidBrush countdownBrush(COLOR_RED);
    Gdiplus::StringFormat countdownFormat;
    countdownFormat.SetAlignment(Gdiplus::StringAlignmentCenter);

    for (int i = 3; i > 0; i--) {
        // Cancella lo schermo
        RECT rect = {0, 0, screenWidth, screenHeight};
        HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));
        FillRect(hdc, &rect, hBrush);
        DeleteObject(hBrush);

        // Disegna il countdown
        std::wstring countdownText = L"SYSTEM DESTRUCTION IN " + std::to_wstring(i);
        Gdiplus::RectF countdownRect(0, screenHeight / 2 - 50, screenWidth, 100);
        graphics.DrawString(countdownText.c_str(), -1, &countdownFont, countdownRect, &countdownFormat, &countdownBrush);

        // Suono di allarme
        GenerateErrorBeepSequence();

        // Pausa
        Sleep(1000);
    }

    // Ultimo avviso drammatico
    {
        // Cancella lo schermo
        RECT rect = {0, 0, screenWidth, screenHeight};
        HBRUSH hBrush = CreateSolidBrush(RGB(0, 0, 0));
        FillRect(hdc, &rect, hBrush);
        DeleteObject(hBrush);

        // Disegna il messaggi finale
        std::wstring finalText = L"INITIATING FINAL DESTRUCTION SEQUENCE";
        Gdiplus::RectF finalRect(0, screenHeight / 2 - 50, screenWidth, 100);
        graphics.DrawString(finalText.c_str(), -1, &countdownFont, finalRect, &countdownFormat, &countdownBrush);

        // Effetto sonoro drammatico
        GenerateExplosionSound();

        // Pausa
        Sleep(2000);
    }

    // Rivela che � uno scherzo
    {
        // Cancella lo schermo
        RECT rect = {0, 0, screenWidth, screenHeight};
        HBRUSH hBrush = CreateSolidBrush(RGB(255, 255, 255));
        FillRect(hdc, &rect, hBrush);
        DeleteObject(hBrush);

        // Disegna il messaggio di rivelazione
        Gdiplus::Font prankFont(L"Arial", 36);
        Gdiplus::Font textFont(L"Arial", 20);
        Gdiplus::SolidBrush textBrush(COLOR_BLACK);
        Gdiplus::StringFormat textFormat;
        textFormat.SetAlignment(Gdiplus::StringAlignmentCenter);

        std::wstring prankText = L"GOTCHA! IT WAS JUST A PRANK!";
        Gdiplus::RectF prankRect(0, screenHeight / 4, screenWidth, 50);
        graphics.DrawString(prankText.c_str(), -1, &prankFont, prankRect, &textFormat, &textBrush);

        std::wstring infoText = L"None of your files were actually damaged or encrypted.\nYour system is completely safe and unharmed.\nThis was just a simulation that looked scary but did nothing harmful.";
        Gdiplus::RectF infoRect(0, screenHeight / 2 - 50, screenWidth, 150);
        graphics.DrawString(infoText.c_str(), -1, &textFont, infoRect, &textFormat, &textBrush);

        std::wstring closeText = L"Click anywhere or press any key to exit...";
        Gdiplus::RectF closeRect(0, screenHeight * 3 / 4, screenWidth, 50);
        graphics.DrawString(closeText.c_str(), -1, &textFont, closeRect, &textFormat, &textBrush);

        // Pulisci le risorse
        ReleaseDC(NULL, hdc);

        // Aspetta che l'utente prema un tasto o faccia clic
        MessageBox(NULL, "GOTCHA! IT WAS JUST A PRANK!\n\nNone of your files were actually damaged or encrypted.\nYour system is completely safe and unharmed.\nThis was just a simulation that looked scary but did nothing harmful.", "NightmareExecutor - Prank Reveal", MB_ICONINFORMATION | MB_OK);
    }

    // Pulisci tutto e termina
    CleanupSimulation();
    shouldExit = true;
}

void SetDestructionStage(DestructionStage stage) {
    currentStage = stage;
    LogMessage("Moving to destruction stage: %d", stage);

    // Aumenta il livello di distruzione con l'avanzare degli stadi
    if (stage > STAGE_INITIALIZATION && stage < STAGE_REVEAL) {
        destructionLevel = ((int)stage * 100) / (int)STAGE_REVEAL;
        if (destructionLevel > MAX_DESTRUCTION_LEVEL) {
            destructionLevel = MAX_DESTRUCTION_LEVEL;
        }
    }
}

bool BackupSystemSettings() {
    // Questa funzione non fa nulla in realt�, solo logging
    LogMessage("System settings backup simulated (no actual backup needed)");
    return true;
}

void RestoreSystemSettings() {
    // Questa funzione non fa nulla in realt�, solo logging
    LogMessage("System settings restore simulated (no actual restore needed)");
}

void CleanupSimulation() {
    LogMessage("Cleaning up simulation resources...");

    // Ripulisci i file temporanei
    WIN32_FIND_DATA findFileData;
    HANDLE hFind = FindFirstFile((tempPath + "*").c_str(), &findFileData);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                std::string filePath = tempPath + findFileData.cFileName;
                DeleteFile(filePath.c_str());
            }
        } while (FindNextFile(hFind, &findFileData) != 0);
        FindClose(hFind);
    }

    // Rimuovi le directory temporanee
    RemoveDirectory((tempPath + "Backup\\").c_str());
    RemoveDirectory((tempPath + "Logs\\").c_str());
    RemoveDirectory(tempPath.c_str());

    LogMessage("All temporary files and directories have been removed");
}

LRESULT CALLBACK MainWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK RansomWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
        case WM_PAINT:
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hWnd, &ps);

                // Disegna la schermata di riscatto
                int width = GetSystemMetrics(SM_CXSCREEN);
                int height = GetSystemMetrics(SM_CYSCREEN);

                // Sfondo nero
                RECT rect = {0, 0, width, height};
                HBRUSH hBrush = CreateSolidBrush(RGB(30, 30, 30));
                FillRect(hdc, &rect, hBrush);
                DeleteObject(hBrush);

                // Disegna usando GDI+
                Gdiplus::Graphics graphics(hdc);

                // Titolo
                Gdiplus::Font titleFont(L"Impact", 48);
                Gdiplus::SolidBrush titleBrush(COLOR_RED);
                Gdiplus::StringFormat titleFormat;
                titleFormat.SetAlignment(Gdiplus::StringAlignmentCenter);

                std::wstring titleText = L"YOUR FILES HAVE BEEN ENCRYPTED";
                Gdiplus::RectF titleRect(0, 50, width, 60);
                graphics.DrawString(titleText.c_str(), -1, &titleFont, titleRect, &titleFormat, &titleBrush);

                // Icona di lucchetto
                int lockSize = 150;
                int lockX = (width - lockSize) / 2;
                int lockY = 150;

                Gdiplus::SolidBrush lockBrush(COLOR_WHITE);
                Gdiplus::Pen lockPen(COLOR_WHITE, 5);

                // Corpo del lucchetto
                graphics.FillRectangle(&lockBrush, lockX, lockY + lockSize / 3, lockSize, lockSize * 2 / 3);

                // Arco del lucchetto
                graphics.DrawArc(&lockPen, lockX + lockSize / 4, lockY, lockSize / 2, lockSize / 2, 180, 180);

                // Testo informativo
                Gdiplus::Font textFont(L"Arial", 18);
                Gdiplus::SolidBrush textBrush(COLOR_WHITE);
                Gdiplus::StringFormat textFormat;
                textFormat.SetAlignment(Gdiplus::StringAlignmentCenter);

                std::wstring infoText = L"All your important files have been encrypted with military grade encryption.\n"
                                       L"To recover your files, you need to pay 500 USD in Bitcoin.\n"
                                       L"You have 48 hours to pay, after which the price will double.\n"
                                       L"After 7 days, all your files will be permanently deleted.";

                Gdiplus::RectF infoRect(width / 8, 350, width * 3 / 4, 150);
                graphics.DrawString(infoText.c_str(), -1, &textFont, infoRect, &textFormat, &textBrush);

                // Istruzioni di pagamento
                Gdiplus::Font paymentFont(L"Consolas", 16);
                Gdiplus::SolidBrush paymentBrush(COLOR_YELLOW);

                std::wstring paymentText = L"Send payment to this Bitcoin address:\n"
                                          L"1Nightmare6789abcdefghijklmnopqrstuv";

                Gdiplus::RectF paymentRect(width / 8, 500, width * 3 / 4, 60);
                graphics.DrawString(paymentText.c_str(), -1, &paymentFont, paymentRect, &textFormat, &paymentBrush);

                // Timer
                Gdiplus::Font timerFont(L"Consolas", 36);
                Gdiplus::SolidBrush timerBrush(COLOR_RED);

                std::wstring timerText = L"47:59:22";

                Gdiplus::RectF timerRect(width / 8, 580, width * 3 / 4, 50);
                graphics.DrawString(timerText.c_str(), -1, &timerFont, timerRect, &textFormat, &timerBrush);

                // Avvertimento
                Gdiplus::Font warningFont(L"Arial", 14);
                Gdiplus::SolidBrush warningBrush(COLOR_RED);

                std::wstring warningText = L"WARNING: Do not attempt to restore your files using third-party software.\n"
                                          L"This will result in permanent data loss!";

                Gdiplus::RectF warningRect(width / 8, 650, width * 3 / 4, 60);
                graphics.DrawString(warningText.c_str(), -1, &warningFont, warningRect, &textFormat, &warningBrush);

                EndPaint(hWnd, &ps);
            }
            break;
        case WM_KEYDOWN:
        case WM_LBUTTONDOWN:
            if (revealMode) {
                DestroyWindow(hWnd);
            }
            break;
        case WM_DESTROY:
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    hInst = hInstance;

    // Inizializza il sistema di simulazione
    InitializeNightmareExecutor();

    // Crea la finestra principale (nascosta)
    CreateMainWindow();

    // Avvia i thread di lavoro
    StartWorkerThreads();

    // Loop dei messaggi della finestra
    MSG msg;
    BOOL bRet;
    while ((bRet = GetMessage(&msg, NULL, 0, 0)) != 0) {
        if (bRet == -1) {
            // Errore, termina
            break;
        } else {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    // Attendi la terminazione dei thread
    StopWorkerThreads();

    // Pulisci e termina
    ShutdownNightmareExecutor();

    return (int)msg.wParam;
}
